const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');

// Tiny .env loader so the backend stays dependency-free.
const ENV_FILE=path.join(__dirname,'..','.env');
if(fs.existsSync(ENV_FILE)){for(const line of fs.readFileSync(ENV_FILE,'utf8').split(/\r?\n/)){const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);if(m&&!process.env[m[1]])process.env[m[1]]=m[2].replace(/^['"]|['"]$/g,'');}}

const ROOT=path.join(__dirname,'..','..');
const DATA=path.join(__dirname,'..','data');
const DB_FILE=path.join(DATA,'db.json');
const PORT=Number(process.env.PORT||5000);
const JWT_SECRET=process.env.JWT_SECRET||'change-this-secret-before-production';
const ADMIN_EMAIL=(process.env.ADMIN_EMAIL||'rahulpamnani2001@gmail.com').trim().toLowerCase();
const ADMIN_PASSWORD=process.env.ADMIN_PASSWORD||'admin123';
const OTP_TTL=Number(process.env.OTP_TTL_MINUTES||5)*60*1000;
fs.mkdirSync(DATA,{recursive:true});
const seed=JSON.parse(fs.readFileSync(path.join(DATA,'seed.json'),'utf8'));
const initialInventory=[
 ...seed.products.map(p=>({skuId:p.id,name:p.name,type:'FINISHED_GOOD',qty:Number(p.stock||0),unit:'pcs',price:Number(p.price||0),location:'Finished Goods',minQty:Number(p.lowStockThreshold||0)})),
 ...seed.rawMaterials.map(r=>({skuId:r.id,name:r.name,type:'RAW_MATERIAL',qty:Number(r.qty||0),unit:r.unit||'pcs',price:Number(r.price||0),location:r.location||'',minQty:Number(r.minQty||0),usedIn:Array.isArray(r.usedIn)?r.usedIn:[]}))
];
const initialDb={products:seed.products,rawMaterials:seed.rawMaterials,productionBatches:seed.productionBatches,stages:seed.stages,orders:[],orderCounter:1001,
  vendors:[
    {vendorId:'VEN-001',vendorName:'Bengal Textile Suppliers',address:'Howrah, West Bengal'},
    {vendorId:'VEN-002',vendorName:'Kolkata Packaging House',address:'Kolkata, West Bengal'},
    {vendorId:'VEN-003',vendorName:'Little Buttons & Accessories',address:'Burrabazar, Kolkata'}
  ],
  inventory:initialInventory,
  purchaseOrders:[
    {poId:'PO-1001',vendorId:'VEN-001',skuId:seed.rawMaterials[0]?.id||'RM001',quantity:100,price:Number(seed.rawMaterials[0]?.price||50),amount:Number((seed.rawMaterials[0]?.price||50)*100),status:'PENDING',createdAt:'2026-10-01T10:00:00.000Z',receivedAt:null},
    {poId:'PO-1002',vendorId:'VEN-002',skuId:seed.rawMaterials.find(r=>/packaging/i.test(r.name))?.id||seed.rawMaterials[1]?.id||'RM002',quantity:50,price:Number(seed.rawMaterials.find(r=>/packaging/i.test(r.name))?.price||8),amount:Number((seed.rawMaterials.find(r=>/packaging/i.test(r.name))?.price||8)*50),status:'RECEIVED',createdAt:'2026-09-25T11:30:00.000Z',receivedAt:'2026-09-27T15:00:00.000Z'}
  ],
  vendorCounter:4,purchaseOrderCounter:1003
};
if(!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE,JSON.stringify(initialDb,null,2));
let db=JSON.parse(fs.readFileSync(DB_FILE,'utf8'));
// Backward-compatible migration: older db.json files receive the new JSON tables automatically.
db.vendors=Array.isArray(db.vendors)?db.vendors:initialDb.vendors;
db.inventory=Array.isArray(db.inventory)?db.inventory:initialInventory;
db.purchaseOrders=Array.isArray(db.purchaseOrders)?db.purchaseOrders:initialDb.purchaseOrders;
// Demo-safe migration: if the procurement tables exist but are empty, populate them
// with the sample records so the ERP screens visibly demonstrate the relationships.
if(db.vendors.length===0) db.vendors=JSON.parse(JSON.stringify(initialDb.vendors));
if(db.inventory.length===0) db.inventory=JSON.parse(JSON.stringify(initialInventory));
if(db.purchaseOrders.length===0) db.purchaseOrders=JSON.parse(JSON.stringify(initialDb.purchaseOrders));
db.vendorCounter=Number(db.vendorCounter||db.vendors.length+1);
db.purchaseOrderCounter=Number(db.purchaseOrderCounter||1001+db.purchaseOrders.length);
function persist(){
  const tmp=DB_FILE+'.tmp';
  fs.writeFileSync(tmp,JSON.stringify(db,null,2));
  fs.renameSync(tmp,DB_FILE);
}
function syncInventoryFromLegacy(){
  const byId=new Map(db.inventory.map(x=>[x.skuId,x]));
  db.rawMaterials.forEach(r=>{const x=byId.get(r.id)||{skuId:r.id};Object.assign(x,{name:r.name,type:'RAW_MATERIAL',qty:Number(r.qty||0),unit:r.unit||'pcs',price:Number(r.price||0),location:r.location||'',minQty:Number(r.minQty||0),usedIn:r.usedIn||[]});byId.set(r.id,x);});
  db.products.forEach(p=>{const x=byId.get(p.id)||{skuId:p.id};Object.assign(x,{name:p.name,type:'FINISHED_GOOD',qty:Number(p.stock||0),unit:'pcs',price:Number(p.price||0),location:'Finished Goods',minQty:Number(p.lowStockThreshold||0)});byId.set(p.id,x);});
  db.inventory=[...byId.values()];
}
syncInventoryFromLegacy();
persist();
const otps=new Map();
const json=(res,status,data)=>{const out=JSON.stringify(data);res.writeHead(status,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS'});res.end(out);};
const parseBody=req=>new Promise((resolve,reject)=>{let s='';req.on('data',c=>s+=c);req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}});});
const sign=email=>{const p=Buffer.from(JSON.stringify({sub:email,role:'admin',exp:Date.now()+8*3600000})).toString('base64url');const h=crypto.createHmac('sha256',JWT_SECRET).update(p).digest('base64url');return p+'.'+h;};
function auth(req){const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))return null;const [p,s]=h.slice(7).split('.');try{const good=crypto.createHmac('sha256',JWT_SECRET).update(p).digest('base64url');if(!crypto.timingSafeEqual(Buffer.from(s),Buffer.from(good)))return null;const x=JSON.parse(Buffer.from(p,'base64url'));return x.exp>Date.now()?x:null}catch(e){return null;}}
async function otpEmail(email,otp){
 if(!process.env.WEB3FORMS_ACCESS_KEY){console.log(`[DEV OTP] ${email}: ${otp}`);return false;}
 try{const body=new URLSearchParams({access_key:process.env.WEB3FORMS_ACCESS_KEY,subject:'OneKid Admin Login OTP',from_name:'OneKid ERP',email,message:`Your OneKid ERP OTP is ${otp}. It expires in ${process.env.OTP_TTL_MINUTES||5} minutes.`});const r=await fetch('https://api.web3forms.com/submit',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});return r.ok}catch(e){console.error('OTP email error:',e.message);return false;}
}
async function api(req,res,url){
 const method=req.method, parts=url.pathname.split('/').filter(Boolean), body=(method==='POST'||method==='PUT')?await parseBody(req):{};
 if(parts[1]==='health')return json(res,200,{ok:true,service:'OneKid ERP API',time:new Date().toISOString()});
 if(parts[1]==='status'&&method==='GET'){
  let writable=false;
  try{fs.accessSync(DATA,fs.constants.R_OK|fs.constants.W_OK);writable=true;}catch(e){}
  return json(res,200,{ok:true,api:'connected',storage:'local-json',database:writable?'connected':'read-only',databaseFile:'backend/data/db.json',counts:{vendors:db.vendors.length,inventory:db.inventory.length,purchaseOrders:db.purchaseOrders.length,rawMaterials:db.rawMaterials.length,products:db.products.length},cloudDatabase:false,emailOtpConfigured:!!process.env.WEB3FORMS_ACCESS_KEY});
 }
 if(parts[1]==='auth'&&parts[2]==='request-otp'&&method==='POST'){
  const email=String(body.email||'').trim().toLowerCase(),password=String(body.password||'');
  if(email!==ADMIN_EMAIL||password!==ADMIN_PASSWORD)return json(res,401,{message:'Invalid admin credentials'});
  const otp=String(crypto.randomInt(100000,1000000));otps.set(email,{hash:crypto.createHash('sha256').update(otp).digest('hex'),expires:Date.now()+OTP_TTL});
  const sent=await otpEmail(email,otp);return json(res,200,{message:sent?'OTP sent to email':'OTP generated in development mode',emailSent:sent,demoOtp:sent?undefined:otp,expiresInSeconds:OTP_TTL/1000});
 }
 if(parts[1]==='auth'&&parts[2]==='verify-otp'&&method==='POST'){
  const email=String(body.email||'').trim().toLowerCase(),otp=String(body.otp||''),item=otps.get(email);
  if(!item||Date.now()>item.expires)return json(res,401,{message:'OTP expired or not requested'});
  const hash=crypto.createHash('sha256').update(otp).digest('hex');if(hash!==item.hash)return json(res,401,{message:'Invalid OTP'});otps.delete(email);return json(res,200,{token:sign(email),expiresIn:28800});
 }
 if(parts[1]==='auth'&&parts[2]==='me'){const u=auth(req);return u?json(res,200,{email:u.sub,role:u.role}):json(res,401,{message:'Authentication required'});}
 if(parts[1]==='admin'&&parts[2]==='database'&&method==='GET'){
  const u=auth(req);if(!u)return json(res,401,{message:'Authentication required'});
  return json(res,200,{storage:'local-json',databaseFile:'backend/data/db.json',counts:{vendors:db.vendors.length,inventory:db.inventory.length,purchaseOrders:db.purchaseOrders.length,rawMaterials:db.rawMaterials.length,products:db.products.length,orders:db.orders.length}});
 }
 if(parts[1]==='products'&&method==='GET')return json(res,200,db.products);
 const user=auth(req);if(!user)return json(res,401,{message:'Authentication required'});
 if(parts[1]==='products'&&parts[2]&&method==='PUT'){const i=db.products.findIndex(x=>x.id===parts[2]);if(i<0)return json(res,404,{message:'Product not found'});db.products[i]={...db.products[i],...body,id:parts[2]};const inv=db.inventory.find(x=>x.skuId===parts[2]);if(inv)Object.assign(inv,{name:db.products[i].name,qty:Number(db.products[i].stock||0),price:Number(db.products[i].price||0),minQty:Number(db.products[i].lowStockThreshold||0)});persist();return json(res,200,db.products[i]);}
 if(parts[1]==='raw-materials'&&method==='GET')return json(res,200,db.rawMaterials);
 if(parts[1]==='raw-materials'&&method==='POST'){const item={...body,id:body.id||`RM${String(db.rawMaterials.length+1).padStart(3,'0')}`};db.rawMaterials.push(item);db.inventory.push({skuId:item.id,name:item.name,type:'RAW_MATERIAL',qty:Number(item.qty||0),unit:item.unit||'pcs',price:Number(item.price||0),location:item.location||'',minQty:Number(item.minQty||0),usedIn:item.usedIn||[]});persist();return json(res,201,item);}
 if(parts[1]==='raw-materials'&&parts[2]&&method==='PUT'){const i=db.rawMaterials.findIndex(x=>x.id===parts[2]);if(i<0)return json(res,404,{message:'Raw material not found'});db.rawMaterials[i]={...db.rawMaterials[i],...body,id:parts[2]};const inv=db.inventory.find(x=>x.skuId===parts[2]);if(inv)Object.assign(inv,{name:db.rawMaterials[i].name,qty:Number(db.rawMaterials[i].qty||0),unit:db.rawMaterials[i].unit,price:Number(db.rawMaterials[i].price||0),location:db.rawMaterials[i].location,minQty:Number(db.rawMaterials[i].minQty||0),usedIn:db.rawMaterials[i].usedIn||[]});persist();return json(res,200,db.rawMaterials[i]);}
 if(parts[1]==='raw-materials'&&parts[2]&&method==='DELETE'){if(db.purchaseOrders.some(po=>po.skuId===parts[2]))return json(res,409,{message:'Raw material cannot be deleted because Purchase Orders reference this SKU ID'});db.rawMaterials=db.rawMaterials.filter(x=>x.id!==parts[2]);db.inventory=db.inventory.filter(x=>x.skuId!==parts[2]);persist();res.writeHead(204,{'Access-Control-Allow-Origin':'*'});return res.end();}

 if(parts[1]==='vendors'&&method==='GET')return json(res,200,db.vendors);
 if(parts[1]==='vendors'&&method==='POST'){
  const vendorName=String(body.vendorName||'').trim(),address=String(body.address||'').trim();
  if(!vendorName)return json(res,400,{message:'Vendor name is required'});
  const vendorId=body.vendorId||`VEN-${String(db.vendorCounter++).padStart(3,'0')}`;
  if(db.vendors.some(v=>v.vendorId===vendorId))return json(res,409,{message:'Vendor ID already exists'});
  const vendor={vendorId,vendorName,address};db.vendors.push(vendor);persist();return json(res,201,vendor);
 }
 if(parts[1]==='vendors'&&parts[2]&&method==='PUT'){
  const i=db.vendors.findIndex(v=>v.vendorId===parts[2]);if(i<0)return json(res,404,{message:'Vendor not found'});
  db.vendors[i]={...db.vendors[i],vendorName:String(body.vendorName||db.vendors[i].vendorName).trim(),address:String(body.address??db.vendors[i].address).trim(),vendorId:parts[2]};persist();return json(res,200,db.vendors[i]);
 }
 if(parts[1]==='vendors'&&parts[2]&&method==='DELETE'){
  if(db.purchaseOrders.some(po=>po.vendorId===parts[2]))return json(res,409,{message:'Vendor cannot be deleted because purchase orders reference this Vendor ID'});
  db.vendors=db.vendors.filter(v=>v.vendorId!==parts[2]);persist();res.writeHead(204,{'Access-Control-Allow-Origin':'*'});return res.end();
 }
 if(parts[1]==='inventory'&&method==='GET')return json(res,200,db.inventory);
 if(parts[1]==='purchase-orders'&&method==='GET'){
  const rows=db.purchaseOrders.map(po=>({...po,vendor:db.vendors.find(v=>v.vendorId===po.vendorId)||null,inventory:db.inventory.find(i=>i.skuId===po.skuId)||null}));
  return json(res,200,rows.sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||''))));
 }
 if(parts[1]==='purchase-orders'&&method==='POST'){
  const vendorId=String(body.vendorId||'').trim(),skuId=String(body.skuId||'').trim(),quantity=Number(body.quantity),price=Number(body.price);
  if(!vendorId||!skuId||!Number.isFinite(quantity)||quantity<=0||!Number.isFinite(price)||price<0)return json(res,400,{message:'Vendor, SKU, positive quantity and valid price are required'});
  if(!db.vendors.some(v=>v.vendorId===vendorId))return json(res,400,{message:`Vendor ID ${vendorId} does not exist in Vendor Master`});
  const sku=db.inventory.find(i=>i.skuId===skuId);
  if(!sku)return json(res,400,{message:`SKU ID ${skuId} does not exist in Inventory`});
  if(sku.type!=='RAW_MATERIAL')return json(res,400,{message:'Purchase Orders can currently be raised only for Raw Material SKUs'});
  const poId=body.poId||`PO-${db.purchaseOrderCounter++}`;
  if(db.purchaseOrders.some(po=>po.poId===poId))return json(res,409,{message:'PO ID already exists'});
  const po={poId,vendorId,skuId,quantity,price,amount:Number((quantity*price).toFixed(2)),status:'PENDING',createdAt:new Date().toISOString(),receivedAt:null};
  db.purchaseOrders.push(po);persist();return json(res,201,{...po,vendor:db.vendors.find(v=>v.vendorId===vendorId),inventory:sku});
 }
 if(parts[1]==='purchase-orders'&&parts[2]&&method==='PUT'&&parts[3]!=='receive'){
  const po=db.purchaseOrders.find(x=>x.poId===parts[2]);if(!po)return json(res,404,{message:'Purchase Order not found'});
  if(po.status==='RECEIVED')return json(res,409,{message:'Received Purchase Orders cannot be edited'});
  const vendorId=String(body.vendorId||po.vendorId).trim(),skuId=String(body.skuId||po.skuId).trim(),quantity=Number(body.quantity??po.quantity),price=Number(body.price??po.price);
  if(!Number.isFinite(quantity)||quantity<=0||!Number.isFinite(price)||price<0)return json(res,400,{message:'Enter a positive quantity and valid price'});
  if(!db.vendors.some(v=>v.vendorId===vendorId))return json(res,400,{message:`Vendor ID ${vendorId} does not exist in Vendor Master`});
  const sku=db.inventory.find(i=>i.skuId===skuId);if(!sku||sku.type!=='RAW_MATERIAL')return json(res,400,{message:'Select an existing Raw Material SKU from Inventory'});
  Object.assign(po,{vendorId,skuId,quantity,price,amount:Number((quantity*price).toFixed(2)),updatedAt:new Date().toISOString()});persist();
  return json(res,200,{...po,vendor:db.vendors.find(v=>v.vendorId===vendorId),inventory:sku});
 }
 if(parts[1]==='purchase-orders'&&parts[2]&&parts[3]==='receive'&&method==='PUT'){
  const po=db.purchaseOrders.find(x=>x.poId===parts[2]);if(!po)return json(res,404,{message:'Purchase Order not found'});
  if(po.status==='RECEIVED')return json(res,409,{message:'Purchase Order has already been received'});
  const sku=db.inventory.find(i=>i.skuId===po.skuId);if(!sku)return json(res,409,{message:'Linked Inventory SKU no longer exists'});
  sku.qty=Number(sku.qty||0)+Number(po.quantity);
  const rm=db.rawMaterials.find(r=>r.id===po.skuId);if(rm)rm.qty=Number(rm.qty||0)+Number(po.quantity);
  po.status='RECEIVED';po.receivedAt=new Date().toISOString();persist();
  return json(res,200,{...po,inventory:sku});
 }
 if(parts[1]==='purchase-orders'&&parts[2]&&method==='DELETE'){
  const i=db.purchaseOrders.findIndex(x=>x.poId===parts[2]);if(i<0)return json(res,404,{message:'Purchase Order not found'});
  if(db.purchaseOrders[i].status==='RECEIVED')return json(res,409,{message:'Received Purchase Orders cannot be deleted'});
  db.purchaseOrders.splice(i,1);persist();res.writeHead(204,{'Access-Control-Allow-Origin':'*'});return res.end();
 }
 if(parts[1]==='production'&&method==='GET')return json(res,200,{stages:db.stages||seed.stages,batches:db.productionBatches});
 if(parts[1]==='production'&&method==='POST'){const b={...body,id:body.id||`BATCH-${String(db.productionBatches.length+1).padStart(3,'0')}`};db.productionBatches.push(b);persist();return json(res,201,b);}
 if(parts[1]==='production'&&parts[2]&&method==='PUT'){const i=db.productionBatches.findIndex(x=>x.id===parts[2]);if(i<0)return json(res,404,{message:'Batch not found'});db.productionBatches[i]={...db.productionBatches[i],...body,id:parts[2]};persist();return json(res,200,db.productionBatches[i]);}
 if(parts[1]==='production'&&parts[2]&&method==='DELETE'){db.productionBatches=db.productionBatches.filter(x=>x.id!==parts[2]);persist();res.writeHead(204,{'Access-Control-Allow-Origin':'*'});return res.end();}
 if(parts[1]==='orders'&&method==='GET')return json(res,200,[...db.orders].sort((a,b)=>String(b.createdAt||'').localeCompare(String(a.createdAt||''))));
 if(parts[1]==='orders'&&method==='POST'){
  if(!body.customer||!body.phone||!Array.isArray(body.items)||!body.items.length)return json(res,400,{message:'Customer and order items are required'});
  for(const item of body.items){const p=db.products.find(x=>x.id===item.id);if(!p)return json(res,400,{message:`Product ${item.id} not found`});if(p.stock<Number(item.qty))return json(res,409,{message:`Insufficient stock for ${p.name}`});}
  body.items.forEach(item=>{db.products.find(x=>x.id===item.id).stock-=Number(item.qty);});
  const order={...body,orderId:`MC-${db.orderCounter++}`,createdAt:new Date().toISOString(),date:body.date||new Date().toLocaleDateString('en-IN'),time:body.time||new Date().toLocaleTimeString('en-IN')};db.orders.push(order);persist();return json(res,201,order);
 }
 if(parts[1]==='dashboard'&&method==='GET'){const revenue=db.orders.reduce((s,o)=>s+Number(o.total||0),0),totalStock=db.products.reduce((s,p)=>s+Number(p.stock||0),0),lowStockItems=db.products.filter(p=>p.stock>0&&p.stock<=p.lowStockThreshold).length;return json(res,200,{totalOrders:db.orders.length,revenue,totalStock,lowStockItems});}
 return json(res,404,{message:'API route not found'});
}
const MIME={'.html':'text/html','.js':'text/javascript','.css':'text/css','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon'};
const server=http.createServer(async(req,res)=>{
 if(req.method==='OPTIONS'){res.writeHead(204,{'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Allow-Methods':'GET,POST,PUT,DELETE,OPTIONS'});return res.end();}
 try{const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);if(url.pathname.startsWith('/api/'))return await api(req,res,url);let file=path.join(ROOT,'frontend',url.pathname==='/'?'index.html':url.pathname);if(!file.startsWith(path.join(ROOT,'frontend')))return json(res,403,{message:'Forbidden'});if(!fs.existsSync(file)||fs.statSync(file).isDirectory())file=path.join(ROOT,'frontend','index.html');res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream'});fs.createReadStream(file).pipe(res);}catch(e){console.error(e);json(res,500,{message:'Internal server error'});}
});
server.listen(PORT,()=>console.log(`OneKid ERP running at http://localhost:${PORT}`));
