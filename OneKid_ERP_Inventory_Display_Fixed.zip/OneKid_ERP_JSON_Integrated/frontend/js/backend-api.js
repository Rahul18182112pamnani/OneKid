/* OneKid ERP - backend adapter
   Keeps the existing UI/business flow while moving persistence/authentication to the Node.js JSON REST API.
*/
(() => {
  const API = (window.ONEKID_API_BASE || ((window.location.protocol === 'file:' || window.location.port === '5500') ? 'http://localhost:5000/api' : window.location.origin + '/api')).replace(/\/$/, '');
  const getToken = () => localStorage.getItem('onekid_access_token') || '';
  async function request(path, options={}) {
    const headers = {'Content-Type':'application/json', ...(options.headers||{})};
    const token = getToken(); if(token) headers.Authorization='Bearer '+token;
    const res = await fetch(API+path,{...options,headers});
    if(res.status===204) return null;
    const data=await res.json().catch(()=>({}));
    if(!res.ok) throw new Error(data.message||`Request failed (${res.status})`);
    return data;
  }
  const publicGet = p => request(p);
  const adminGet = p => request(p);

  // Backend-backed product persistence.
  window.saveProducts = async function(){
    try {
      await Promise.all(products.map(p=>request('/products/'+encodeURIComponent(p.id),{method:'PUT',body:JSON.stringify(p)})));
      localStorage.setItem('onekid_products',JSON.stringify(products));
      return true;
    } catch(e) { console.error(e); showToast('⚠️ Could not sync product changes: '+e.message); return false; }
  };

  window.loadSavedProducts = async function(){
    try { const remote=await publicGet('/products'); if(Array.isArray(remote)&&remote.length){ products=remote; localStorage.setItem('onekid_products',JSON.stringify(remote)); return; } }
    catch(e){ console.warn('Product API unavailable, using local seed',e.message); }
    const saved=localStorage.getItem('onekid_products'); if(saved) products=JSON.parse(saved);
  };

  window.loadOrders = async function(){
    try { orders=await adminGet('/orders'); localStorage.setItem('onekid_orders',JSON.stringify(orders)); }
    catch(e){ const saved=localStorage.getItem('onekid_orders'); if(saved) orders=JSON.parse(saved); console.warn(e); }
    renderOrderTables(); updateAdminStats();
  };

  window.sendOTP = async function(){
    const email=document.getElementById('adminEmail').value.trim();
    const password=document.getElementById('adminPassword').value;
    if(!email||!password){showAlert('⚠️ Enter email and password','error');return;}
    const btn=document.getElementById('loginBtn'); btn.disabled=true; btn.innerHTML='<span class="loading"></span> Sending OTP...';
    try {
      const data=await request('/auth/request-otp',{method:'POST',body:JSON.stringify({email,password})});
      window.__otpEmail=email;
      window.__otpExpiresAt=Date.now()+(Number(data.expiresInSeconds||300)*1000);
      if(data.demoOtp) console.warn('Demo OTP (email provider not configured):',data.demoOtp);
      showAlert(data.emailSent?'✅ OTP sent! Check your email.':'⚠️ Email is not configured. Your development OTP is: '+(data.demoOtp||'Check backend terminal'),'success');
      document.getElementById('loginForm').classList.add('hide'); document.getElementById('otpForm').classList.remove('hide');
      document.getElementById('otpEmail').textContent=email; for(let i=1;i<=6;i++)document.getElementById('otp'+i).value=''; startOTPTimer(); document.getElementById('otp1').focus();
    } catch(e){showAlert('❌ '+e.message,'error');}
    finally{btn.disabled=false;btn.innerHTML='<i class="fas fa-paper-plane"></i> Send OTP to Email';}
  };

  window.verifyOTP = async function(){
    const otp=Array.from({length:6},(_,i)=>document.getElementById('otp'+(i+1)).value).join('');
    const email=document.getElementById('adminEmail').value.trim() || window.__otpEmail;
    if(otp.length!==6){showAlert('⚠️ Enter complete 6-digit code','error');return;}
    if(window.__otpExpiresAt && Date.now()>window.__otpExpiresAt){showAlert('❌ OTP expired. Request a new one.','error');return;}
    try {
      const data=await request('/auth/verify-otp',{method:'POST',body:JSON.stringify({email,otp})});
      localStorage.setItem('onekid_access_token',data.token); CONFIG.adminLoggedIn=true;
      document.getElementById('adminLoginModal').classList.remove('active'); document.getElementById('heroSection').style.display='none'; document.getElementById('shopSection').style.display='none'; document.getElementById('cartSection').classList.add('hide'); document.getElementById('adminSection').classList.remove('hide');
      document.querySelectorAll('.nav-item').forEach((item,i)=>item.classList.toggle('active',i===3));
      showToast('✅ Admin login successful! Syncing from backend...',2500); await refreshAdminData();
    } catch(e){showAlert('❌ '+e.message,'error');}
  };

  async function refreshAdminData(){
    // Load each register independently so a Production API error cannot blank
    // or prevent the Raw Materials inventory from rendering.
    try {
      const materials = await adminGet('/raw-materials');
      rawMaterials = Array.isArray(materials) ? materials.map(r => ({
        ...r, qty:Number(r.qty ?? 0), price:Number(r.price ?? 0),
        minQty:Number(r.minQty ?? 0), usedIn:Array.isArray(r.usedIn)?r.usedIn:[],
        unit:r.unit||'pcs', location:r.location||'Not specified'
      })) : [];
      if (typeof loadRawMaterials === 'function') loadRawMaterials();
    } catch(e) {
      console.error('Raw Materials could not be loaded:',e);
      const body=document.getElementById('rawMaterialsBody');
      if(body) body.innerHTML='<tr><td colspan="10" style="color:#b02a37;text-align:center;padding:18px;">Could not load Raw Materials. Check the backend connection and sign in again.</td></tr>';
    }
    try {
      const prod=await adminGet('/production');
      productionBatches=Array.isArray(prod.batches)?prod.batches:[];
      if(typeof renderProductionBatches==='function') renderProductionBatches();
    } catch(e) { console.warn('Production data could not be loaded:',e); }
    await loadOrders();
    await loadProcurementData();
    updateAdminStats();
  }


  // Always refresh the Raw Materials register from the backend when its tab opens.
  const originalSwitchAdminTab = window.switchAdminTab;
  if (typeof originalSwitchAdminTab === 'function') {
    window.switchAdminTab = function(tabId, btn) {
      originalSwitchAdminTab(tabId, btn);
      if (tabId === 'tab-rawmaterials' && CONFIG.adminLoggedIn) {
        adminGet('/raw-materials').then(rows => {
          rawMaterials = Array.isArray(rows) ? rows.map(r => ({
            ...r, qty:Number(r.qty ?? 0), price:Number(r.price ?? 0),
            minQty:Number(r.minQty ?? 0), usedIn:Array.isArray(r.usedIn)?r.usedIn:[],
            unit:r.unit||'pcs', location:r.location||'Not specified'
          })) : [];
          if(typeof loadRawMaterials==='function') loadRawMaterials();
        }).catch(e => { console.error(e); showToast('Could not refresh Raw Materials: '+e.message,4000); });
      }
    };
  }

  window.checkDatabaseConnection = async function(){
    const statusEl=document.getElementById('firebaseStatus'),box=document.getElementById('firebaseSetupBox');
    try{
      const status=await publicGet('/status');
      if(statusEl) statusEl.textContent=status.database==='connected'?'✓ Connected — local JSON database':'⚠️ Database folder is read-only';
      if(box) box.style.borderColor=status.database==='connected'?'#28a745':'#dc3545';
      const counts=document.getElementById('databaseCounts');
      if(counts) counts.textContent=`${status.counts.vendors} vendors · ${status.counts.inventory} SKUs · ${status.counts.purchaseOrders} purchase orders`;
      return status;
    }catch(e){
      if(statusEl) statusEl.textContent='✕ Backend unavailable — '+e.message;
      if(box) box.style.borderColor='#dc3545';
      return null;
    }
  };

  window.initApp = async function(){
    await loadSavedProducts(); loadSavedImages(); loadProducts(); updateCartDisplay(); updateAdminStats(); await checkDatabaseConnection();
    const token=getToken(); if(token){try{await request('/auth/me'); CONFIG.adminLoggedIn=true;}catch(e){localStorage.removeItem('onekid_access_token');}}
    console.log('✅ OneKid ERP initialized with Node.js + local JSON backend');
  };

  window.saveNewRM = async function(){
    const name=document.getElementById('rmName').value.trim(), qty=parseInt(document.getElementById('rmQty').value), price=parseFloat(document.getElementById('rmPrice').value), minQty=parseInt(document.getElementById('rmMin').value);
    if(!name||isNaN(qty)||isNaN(price)||isNaN(minQty)){showToast('⚠️ Fill all fields');return;}
    try{const item=await request('/raw-materials',{method:'POST',body:JSON.stringify({name,usedIn:[],location:document.getElementById('rmLocation').value,qty,unit:document.getElementById('rmUnit').value,price,minQty})});rawMaterials.push(item);closeModal('addRMModal');loadRawMaterials();showToast('✅ '+name+' added!');}catch(e){showToast('❌ '+e.message);}
  };
  window.restockRM = async function(idx){const rm=rawMaterials[idx];const qty=parseInt(prompt('Add stock for '+rm.name+' (current: '+rm.qty+' '+rm.unit+'):', '50'));if(!qty||qty<1)return;try{const updated=await request('/raw-materials/'+rm.id,{method:'PUT',body:JSON.stringify({qty:rm.qty+qty})});rawMaterials[idx]=updated;loadRawMaterials();showToast('✅ '+rm.name+' restocked!');}catch(e){showToast('❌ '+e.message);}};
  window.deleteRM = async function(idx){const rm=rawMaterials[idx];if(!confirm('Delete '+rm.name+' from raw materials?'))return;try{await request('/raw-materials/'+rm.id,{method:'DELETE'});rawMaterials.splice(idx,1);loadRawMaterials();showToast('🗑️ '+rm.name+' removed');}catch(e){showToast('❌ '+e.message);}};

  window.createNewBatch = async function(){
    const code=document.getElementById('batchProduct').value, qty=parseInt(document.getElementById('batchQty').value), prod=products.find(p=>p.id===code);
    if(!code||!qty||qty<1||!prod){showToast('⚠️ Select product and quantity');return;}
    const today=new Date().toISOString().split('T')[0], b={id:'BATCH-'+String(productionBatches.length+1).padStart(3,'0'),product:prod.name,code,qty,currentStage:1,createdDate:today,stages:[{s:1,status:'in-progress',date:today,qty},{s:2,status:'pending',date:null,qty:0},{s:3,status:'pending',date:null,qty:0},{s:4,status:'pending',date:null,qty:0},{s:5,status:'pending',date:null,qty:0}]};
    try{const saved=await request('/production',{method:'POST',body:JSON.stringify(b)});productionBatches.push(saved);closeModal('newBatchModal');renderProductionBatches();showToast('✅ '+saved.id+' started!');}catch(e){showToast('❌ '+e.message);}
  };
  window.advanceStage = async function(idx){const b=productionBatches[idx];if(!b)return;const names=['Cutting','Printing','Embroidery','Stitching','Packaging'],loc=['Howrah-Cutting','Dhulagarh','Arambagh','Moyna','Howrah-Packaging'];b.stages[b.currentStage-1].status='done';if(b.currentStage<5){b.currentStage++;const d=new Date().toISOString().split('T')[0];b.stages[b.currentStage-1]={s:b.currentStage,status:'in-progress',date:d,qty:b.stages[b.currentStage-2].qty};}try{productionBatches[idx]=await request('/production/'+b.id,{method:'PUT',body:JSON.stringify(b)});renderProductionBatches();showToast('✅ '+b.id+' → '+names[b.currentStage-1]+' at '+loc[b.currentStage-1]);}catch(e){showToast('❌ '+e.message);}};
  window.completeBatch = async function(idx){const b=productionBatches[idx];if(!b)return;b.stages[4].status='done';b.stages[4].date=new Date().toISOString().split('T')[0];b.stages[4].qty=b.qty;const p=products.find(x=>x.id===b.code);try{if(p){p.stock+=b.qty;await request('/products/'+p.id,{method:'PUT',body:JSON.stringify(p)});}await request('/production/'+b.id,{method:'DELETE'});productionBatches.splice(idx,1);renderProductionBatches();loadProducts();updateAdminStats();showToast('🎉 '+b.id+' completed! +'+b.qty+' added to stock.');}catch(e){showToast('❌ '+e.message);}};

  // Replace checkout persistence: server validates stock and creates the order.
  window.saveOrderToFirebase = async function(order){try{const saved=await request('/orders',{method:'POST',body:JSON.stringify(order)});return !!saved;}catch(e){console.error(e);showAlert('❌ '+e.message,'error');return false;}};
  window.saveOrders = async function(){localStorage.setItem('onekid_orders',JSON.stringify(orders));};

  // ===== Vendor Master + Purchase Order module =====
  let vendorsCache = [], inventoryCache = [], purchaseOrdersCache = [];
  let editingVendorId = null, editingPoId = null;
  function byId(id){ const el=document.getElementById(id); if(!el) throw new Error('Missing form field: '+id); return el; }
  function escapeHtml(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
  window.openVendorModal = function(vendorId){
    editingVendorId=vendorId||null;
    const vendor=vendorId?vendorsCache.find(v=>v.vendorId===vendorId):null;
    byId('vendorName').value=vendor?.vendorName||'';
    byId('vendorAddress').value=vendor?.address||'';
    const title=byId('vendorModal').querySelector('h3'); if(title)title.textContent=vendor?'✏️ Edit Vendor':'🏪 Add Vendor';
    const save=byId('vendorModal').querySelector('button[onclick="saveVendor()"]'); if(save)save.textContent=vendor?'Update Vendor':'Save Vendor';
    byId('vendorModal').style.display='flex'; byId('vendorModal').setAttribute('aria-hidden','false');
  };
  window.openPOModal = async function(poId){
    try{
      const loaded=await loadProcurementData(); if(!loaded) throw new Error('Could not load Vendor Master / Inventory. Check backend connection and login.');
      editingPoId=poId||null;
      const po=poId?purchaseOrdersCache.find(x=>x.poId===poId):null;
      if(po && po.status!=='PENDING') throw new Error('Only pending purchase orders can be edited.');
      const v=byId('poVendor'), sku=byId('poSku');
      v.innerHTML='<option value="">-- Select vendor --</option>'+vendorsCache.map(x=>`<option value="${escapeHtml(x.vendorId)}">${escapeHtml(x.vendorId)} — ${escapeHtml(x.vendorName)}</option>`).join('');
      sku.innerHTML='<option value="">-- Select raw material --</option>'+inventoryCache.filter(x=>x.type==='RAW_MATERIAL').map(x=>`<option value="${escapeHtml(x.skuId)}">${escapeHtml(x.skuId)} — ${escapeHtml(x.name)} (${Number(x.qty)} ${escapeHtml(x.unit)})</option>`).join('');
      v.value=po?.vendorId||''; sku.value=po?.skuId||'';
      byId('poQty').value=po?.quantity??50; byId('poPrice').value=po?.price??(inventoryCache.find(x=>x.skuId===sku.value)?.price||0);
      const title=byId('purchaseOrderModal').querySelector('h3'); if(title)title.textContent=po?'✏️ Edit Purchase Order':'📋 New Purchase Order';
      const save=byId('purchaseOrderModal').querySelector('button[onclick="savePurchaseOrder()"]'); if(save)save.textContent=po?'Update PO':'Create PO';
      updatePOAmount(); byId('purchaseOrderModal').style.display='flex'; byId('purchaseOrderModal').setAttribute('aria-hidden','false');
    }catch(e){showToast('❌ '+e.message,4000);}
  };
  window.updatePOPrice=function(){const sku=inventoryCache.find(x=>x.skuId===byId('poSku').value);byId('poPrice').value=sku?Number(sku.price||0):0;updatePOAmount();};
  window.updatePOAmount=function(){const q=Number(byId('poQty').value||0),p=Number(byId('poPrice').value||0);byId('poAmountPreview').textContent='₹'+(q*p).toFixed(2);};
  window.saveVendor=async function(){
    const vendorName=byId('vendorName').value.trim(),address=byId('vendorAddress').value.trim();
    if(!vendorName){showToast('⚠️ Enter vendor name');byId('vendorName').focus();return;}
    const btn=byId('vendorModal').querySelector('button[onclick="saveVendor()"]'); if(btn){btn.disabled=true;btn.textContent='Saving...';}
    try{
      const path=editingVendorId?'/vendors/'+encodeURIComponent(editingVendorId):'/vendors';
      await request(path,{method:editingVendorId?'PUT':'POST',body:JSON.stringify({vendorName,address})});
      closeProcurementModal('vendorModal');await loadProcurementData();showToast(editingVendorId?'✅ Vendor updated':'✅ Vendor added to Vendor Master');editingVendorId=null;
    }catch(e){showToast('❌ '+e.message,4000);}
    finally{if(btn){btn.disabled=false;btn.textContent='Save Vendor';}}
  };
  window.savePurchaseOrder=async function(){
    const vendorId=byId('poVendor').value,skuId=byId('poSku').value,quantity=Number(byId('poQty').value),price=Number(byId('poPrice').value);
    if(!vendorId||!skuId||!Number.isFinite(quantity)||quantity<=0||!Number.isFinite(price)||price<0){showToast('⚠️ Select a vendor and SKU, enter a positive quantity and valid price');return;}
    const btn=byId('purchaseOrderModal').querySelector('button[onclick="savePurchaseOrder()"]');if(btn){btn.disabled=true;btn.textContent='Saving...';}
    try{
      const path=editingPoId?'/purchase-orders/'+encodeURIComponent(editingPoId):'/purchase-orders';
      await request(path,{method:editingPoId?'PUT':'POST',body:JSON.stringify({vendorId,skuId,quantity,price})});
      closeProcurementModal('purchaseOrderModal');await loadProcurementData();showToast(editingPoId?'✅ Purchase Order updated':'✅ Purchase Order created');editingPoId=null;
    }catch(e){showToast('❌ '+e.message,4000);}
    finally{if(btn){btn.disabled=false;btn.textContent='Create PO';}}
  };
  window.receivePurchaseOrder=async function(poId){if(!confirm('Mark '+poId+' as RECEIVED? This will add the ordered quantity to inventory.'))return;try{await request('/purchase-orders/'+encodeURIComponent(poId)+'/receive',{method:'PUT'});await loadProcurementData();await refreshAdminData();showToast('📦 '+poId+' received — inventory updated');}catch(e){showToast('❌ '+e.message,4000);}};
  window.deletePurchaseOrder=async function(poId){if(!confirm('Delete '+poId+'? Only pending POs can be deleted.'))return;try{await request('/purchase-orders/'+encodeURIComponent(poId),{method:'DELETE'});await loadProcurementData();showToast('🗑️ '+poId+' deleted');}catch(e){showToast('❌ '+e.message,4000);}};
  window.deleteVendor=async function(vendorId){if(!confirm('Delete '+vendorId+'? Vendors referenced by a PO cannot be deleted.'))return;try{await request('/vendors/'+encodeURIComponent(vendorId),{method:'DELETE'});await loadProcurementData();showToast('🗑️ Vendor removed');}catch(e){showToast('❌ '+e.message,4000);}};
  async function loadProcurementData(){
    try{const [v,i,p]=await Promise.all([adminGet('/vendors'),adminGet('/inventory'),adminGet('/purchase-orders')]);vendorsCache=v;inventoryCache=i;purchaseOrdersCache=p;renderVendors();renderPurchaseOrders();return true;}
    catch(e){console.error('Procurement data error:',e);const vb=document.getElementById('vendorMasterBody'),pb=document.getElementById('purchaseOrdersBody');if(vb)vb.innerHTML=`<tr><td colspan="5" style="color:#b02a37;padding:18px;text-align:center;">Could not load vendors: ${escapeHtml(e.message)}</td></tr>`;if(pb)pb.innerHTML=`<tr><td colspan="10" style="color:#b02a37;padding:18px;text-align:center;">Could not load purchase orders: ${escapeHtml(e.message)}</td></tr>`;showToast('⚠️ Could not load Vendor/PO data: '+e.message,5000);return false;}
  }
  window.refreshProcurementTables=loadProcurementData;
  function renderVendors(){
    const el=document.getElementById('vendorMasterBody');if(!el)return;
    el.innerHTML=vendorsCache.length?vendorsCache.map(v=>{const count=purchaseOrdersCache.filter(po=>po.vendorId===v.vendorId).length;return `<tr><td><strong>${escapeHtml(v.vendorId)}</strong></td><td>${escapeHtml(v.vendorName)}</td><td>${escapeHtml(v.address||'—')}</td><td>${count}</td><td><button onclick="openVendorModal('${escapeHtml(v.vendorId)}')" style="padding:5px 8px;border:1px solid #0d6efd;background:white;color:#0d6efd;border-radius:6px;cursor:pointer;margin-right:4px;">Edit</button><button onclick="deleteVendor('${escapeHtml(v.vendorId)}')" style="padding:5px 8px;border:1px solid #dc3545;background:white;color:#dc3545;border-radius:6px;cursor:pointer;">Delete</button></td></tr>`}).join(''):'<tr><td colspan="5" style="text-align:center;color:#999;padding:20px;">No vendors yet. Select “Add Vendor” to create your first record.</td></tr>';
  }
  function renderPurchaseOrders(){
    const el=document.getElementById('purchaseOrdersBody');if(!el)return;
    const pending=purchaseOrdersCache.filter(x=>x.status==='PENDING').reduce((s,x)=>s+Number(x.amount||0),0),received=purchaseOrdersCache.filter(x=>x.status==='RECEIVED').reduce((s,x)=>s+Number(x.amount||0),0);
    byId('poCount').textContent=purchaseOrdersCache.length;byId('poPendingValue').textContent='₹'+pending.toFixed(2);byId('poReceivedValue').textContent='₹'+received.toFixed(2);
    el.innerHTML=purchaseOrdersCache.length?purchaseOrdersCache.map(po=>{const status=po.status==='RECEIVED'?'<span style="background:#d4edda;color:#155724;padding:4px 8px;border-radius:10px;font-size:11px;font-weight:700;">RECEIVED</span>':'<span style="background:#fff3cd;color:#856404;padding:4px 8px;border-radius:10px;font-size:11px;font-weight:700;">PENDING</span>';const action=po.status==='RECEIVED'?'<span style="color:#27ae60;font-size:12px;">Stock updated</span>':`<button onclick="openPOModal('${escapeHtml(po.poId)}')" style="padding:5px 8px;border:1px solid #0d6efd;background:white;color:#0d6efd;border-radius:6px;cursor:pointer;margin-right:4px;">Edit</button><button onclick="receivePurchaseOrder('${escapeHtml(po.poId)}')" style="padding:5px 8px;border:1px solid #16a085;background:#e9fbf6;color:#117864;border-radius:6px;cursor:pointer;margin-right:4px;">Receive</button><button onclick="deletePurchaseOrder('${escapeHtml(po.poId)}')" style="padding:5px 8px;border:1px solid #dc3545;background:white;color:#dc3545;border-radius:6px;cursor:pointer;">Delete</button>`;return `<tr><td><strong>${escapeHtml(po.poId)}</strong></td><td>${escapeHtml(po.vendorId)}</td><td>${escapeHtml(po.vendor?.vendorName||'—')}</td><td>${escapeHtml(po.skuId)}</td><td>${escapeHtml(po.inventory?.name||'—')}</td><td>${Number(po.quantity)}</td><td>₹${Number(po.price).toFixed(2)}</td><td><strong>₹${Number(po.amount).toFixed(2)}</strong></td><td>${status}</td><td>${action}</td></tr>`}).join(''):'<tr><td colspan="10" style="text-align:center;color:#999;padding:20px;">No purchase orders yet. Select “New Purchase Order” to create one.</td></tr>';
  }


  // Reliable procurement modal controls. The original UI mixes inline display styles
  // with the .modal active class; use both so the dialogs work across browsers.
  const closeProcurementModal = (id) => {
    const el=document.getElementById(id);
    if(!el)return;
    el.classList.remove('active');
    el.style.display='none';
    el.setAttribute('aria-hidden','true');
  };
  window.closeProcurementModal=closeProcurementModal;
  // Explicit listeners supplement legacy inline onclick attributes. This also makes
  // the main buttons work if inline handlers are blocked by browser extensions/CSP.
  document.addEventListener('DOMContentLoaded',()=>{
    const addVendor=document.getElementById('addVendorButton');
    const newPO=document.getElementById('newPurchaseOrderButton');
    if(addVendor)addVendor.addEventListener('click',e=>{e.preventDefault();window.openVendorModal();});
    if(newPO)newPO.addEventListener('click',e=>{e.preventDefault();window.openPOModal();});
    ['vendorModal','purchaseOrderModal'].forEach(id=>{
      const modal=document.getElementById(id);
      if(modal){modal.addEventListener('click',e=>{if(e.target===modal)closeProcurementModal(id);});modal.setAttribute('aria-hidden','true');}
    });
  });

  // Make logout invalidate the local bearer token.
  window.logout = function(){if(confirm('Logout from Admin?')){localStorage.removeItem('onekid_access_token');CONFIG.adminLoggedIn=false;showSection('home');showToast('👋 Logged out from Admin',2000);}};
})();
