// ===== CONFIGURATION =====
        // ===== FIREBASE CONFIG =====
        // Paste your Firebase config here after creating project
                // ===== FIREBASE CONFIG — PERMANENTLY HARDCODED =====
        // No need to paste config on any device. Works everywhere automatically.
        // ===== FIREBASE REST API — NO SDK, NO CDN =====
        const FB_PROJECT = 'onekid-8d0ec';
        const FB_API_KEY = 'AIzaSyB8WphxjSmM_ZnpZSLueAWHDMePLx_s5WE';
        const FB_BASE = 'https://firestore.googleapis.com/v1/projects/' + FB_PROJECT + '/databases/(default)/documents';
        let db = true; // flag: REST API is always "ready"

        function initFirebase() { return true; }

        function fsVal(v) {
            if (v === null || v === undefined) return { nullValue: null };
            if (typeof v === 'string')  return { stringValue: v };
            if (typeof v === 'boolean') return { booleanValue: v };
            if (typeof v === 'number')  return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
            if (Array.isArray(v))       return { arrayValue: { values: v.map(fsVal) } };
            if (typeof v === 'object')  return { mapValue: { fields: Object.fromEntries(Object.entries(v).map(([k,x]) => [k, fsVal(x)])) } };
            return { stringValue: String(v) };
        }
        function fsFromVal(v) {
            if (v.nullValue    !== undefined) return null;
            if (v.stringValue  !== undefined) return v.stringValue;
            if (v.booleanValue !== undefined) return v.booleanValue;
            if (v.integerValue !== undefined) return Number(v.integerValue);
            if (v.doubleValue  !== undefined) return v.doubleValue;
            if (v.timestampValue !== undefined) return v.timestampValue;
            if (v.arrayValue)  return (v.arrayValue.values || []).map(fsFromVal);
            if (v.mapValue)    return Object.fromEntries(Object.entries(v.mapValue.fields || {}).map(([k,x]) => [k, fsFromVal(x)]));
            return null;
        }
        function fsToObj(doc) {
            if (!doc || !doc.fields) return {};
            return Object.fromEntries(Object.entries(doc.fields).map(([k,v]) => [k, fsFromVal(v)]));
        }
        function fsFromObj(obj) {
            return Object.fromEntries(Object.entries(obj).map(([k,v]) => [k, fsVal(v)]));
        }
        async function fsSet(col, docId, data) {
            const url = FB_BASE + '/' + col + '/' + encodeURIComponent(docId) + '?key=' + FB_API_KEY;
            const res = await fetch(url, { method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ fields: fsFromObj(data) }) });
            if (!res.ok) throw new Error('fsSet ' + res.status);
        }
        async function fsGet(col, docId) {
            const url = FB_BASE + '/' + col + '/' + encodeURIComponent(docId) + '?key=' + FB_API_KEY;
            const res = await fetch(url);
            if (res.status === 404) return null;
            if (!res.ok) throw new Error('fsGet ' + res.status);
            return fsToObj(await res.json());
        }
        async function fsList(col) {
            const url = FB_BASE + '/' + col + '?key=' + FB_API_KEY + '&pageSize=200';
            const res = await fetch(url);
            if (!res.ok) {
                const err = await res.json().catch(() => ({}));
                const msg = (err.error && err.error.message) || res.status;
                throw new Error('Firestore ' + col + ': ' + msg);
            }
            const data = await res.json();
            return (data.documents || []).map(doc => ({ ...fsToObj(doc), _id: doc.name.split('/').pop() }));
        }
        document.addEventListener('DOMContentLoaded', () => console.log('✅ Firebase REST API ready — onekid-8d0ec'));

        const CONFIG = {
            web3formsKey: '75a61894-a929-4cb6-8f43-5c40a4f5fc03',
            adminEmail: 'rahulpamnani2001@gmail.com',
            adminPassword: 'admin123',
            emailjsServiceId:  'service_tueazqz',
            emailjsTemplateId: 'template_03s58rk',
            emailjsPublicKey:  'VNEA1OWpm07aAe5gw',
            currentOTP: null,
            otpExpiry: null,
            adminLoggedIn: false,
            businessInfo: {
                name: 'OneKid by Mohini Creations',
                address: 'Keshav Apartment, Howrah AC Market, Kings Road, Howrah - 711101',
                phone: '9038023000',
                email: 'rahulpamnani2001@gmail.com',
                contact: 'Mr. Piyush Bacchawat',
                gpsCoords: '22.583896,88.344630'
            }
        };

        // Restore EmailJS settings saved in Integration Setup. Without this, the form
        // can say "Connected" during one session but checkout may use stale defaults
        // after a reload.
        try {
            CONFIG.emailjsServiceId = localStorage.getItem('emailjs_service_id') || CONFIG.emailjsServiceId || '';
            CONFIG.emailjsTemplateId = localStorage.getItem('emailjs_template_id') || CONFIG.emailjsTemplateId || '';
            CONFIG.emailjsPublicKey = localStorage.getItem('emailjs_public_key') || CONFIG.emailjsPublicKey || '';
        } catch (storageError) {
            console.warn('Could not restore EmailJS settings:', storageError);
        }

        // Product Database with editable fields
        let products = [
            { id: 'ROM001', name: 'Cotton Romper', price: 299, size: '0-3m', color: 'Blue', stock: 148, lowStockThreshold: 30, category: '0-3', emoji: '🦋', fabric: 'Cotton', print: 'Solid', image: null },
            { id: 'ROM002', name: 'Pink Romper', price: 299, size: '0-3m', color: 'Pink', stock: 118, lowStockThreshold: 25, category: '0-3', emoji: '🦋', fabric: 'Cotton Blend', print: 'Polka Dots', image: null },
            { id: 'ONE002', name: 'Soft Onesie', price: 199, size: '3-6m', color: 'Pink', stock: 44, lowStockThreshold: 12, category: '3-6', emoji: '🌸', fabric: 'Jersey', print: 'Floral', image: null },
            { id: 'ONE003', name: 'Striped Onesie', price: 199, size: '3-6m', color: 'Multi', stock: 58, lowStockThreshold: 15, category: '3-6', emoji: '🌈', fabric: 'Cotton', print: 'Stripes', image: null },
            { id: 'JHA003', name: 'Traditional Jhapla', price: 149, size: '6-9m', color: 'White', stock: 11, lowStockThreshold: 8, category: '6-12', emoji: '☁️', fabric: 'Muslin', print: 'Solid', image: null },
            { id: 'JHA004', name: 'Colored Jhapla', price: 249, size: '6-9m', color: 'Multi', stock: 29, lowStockThreshold: 10, category: '6-12', emoji: '🎨', fabric: 'Cotton', print: 'Animal Print', image: null },
            { id: 'DUN004', name: 'Denim Dungarees', price: 349, size: '6-12m', color: 'Blue', stock: 34, lowStockThreshold: 10, category: '6-12', emoji: '👖', fabric: 'Denim', print: 'Solid', image: null },
            { id: 'KUR001', name: 'Ethnic Kurta', price: 399, size: '6-12m', color: 'Gold', stock: 24, lowStockThreshold: 8, category: '6-12', emoji: '✨', fabric: 'Silk Blend', print: 'Embroidered', image: null },
            { id: 'DRS001', name: 'Floral Dress', price: 299, size: '6-12m', color: 'Pink', stock: 39, lowStockThreshold: 12, category: '6-12', emoji: '🌺', fabric: 'Cotton Voile', print: 'Floral', image: null },
            { id: 'SET001', name: 'Ocean Set', price: 449, size: '12-18m', color: 'Blue', stock: 24, lowStockThreshold: 8, category: '6-12', emoji: '🐟', fabric: 'Interlock', print: 'Sea Creatures', image: null }
        ];

        let cart = [];
        let orders = [];
        let orderCounter = 1001;
        let currentUploadProductId = null;
        let currentRestockProductId = null;
        let currentEditProductId = null;
        let currentConfirmOrder = null;

        // Save/Load products from localStorage
        function saveProducts() {
            localStorage.setItem('onekid_products', JSON.stringify(products));
            localStorage.setItem('onekid_products_version', PRODUCTS_VERSION);
            console.log('💾 Products saved to localStorage');
        }

        const PRODUCTS_VERSION = 'v4';

        // ===== RAW MATERIALS =====
        let rawMaterials = [
            { id:'RM001', name:'Cotton Fabric (White)',   usedIn:['ROM001','ROM002'], location:'Moyna',            qty:80,  unit:'meters',  price:50,  minQty:20 },
            { id:'RM002', name:'Cotton Fabric (Colored)', usedIn:['ONE002','ONE003'], location:'Moyna',            qty:60,  unit:'meters',  price:55,  minQty:15 },
            { id:'RM003', name:'Muslin Fabric',           usedIn:['JHA003','JHA004'], location:'Moyna',            qty:40,  unit:'meters',  price:70,  minQty:10 },
            { id:'RM004', name:'Denim Fabric',            usedIn:['DUN004'],          location:'Howrah-Cutting',   qty:35,  unit:'meters',  price:120, minQty:10 },
            { id:'RM005', name:'Silk Blend Fabric',       usedIn:['KUR001'],          location:'Arambagh',         qty:25,  unit:'meters',  price:180, minQty:8  },
            { id:'RM006', name:'Floral Voile Fabric',     usedIn:['DRS001','SET001'], location:'Moyna',            qty:45,  unit:'meters',  price:90,  minQty:12 },
            { id:'RM007', name:'Thread (Multi-color)',    usedIn:['ROM001','ROM002','ONE002','ONE003','JHA003','JHA004','DUN004','KUR001','DRS001','SET001'], location:'Moyna', qty:200, unit:'spools', price:15, minQty:50 },
            { id:'RM008', name:'Buttons (Small)',         usedIn:['ROM001','ONE002','JHA003'], location:'Moyna',   qty:500, unit:'pcs',     price:2,   minQty:100 },
            { id:'RM009', name:'Zippers',                 usedIn:['DUN004'],          location:'Howrah-Packaging', qty:40,  unit:'pcs',     price:8,   minQty:10 },
            { id:'RM010', name:'Elastic Band',            usedIn:['ONE002','ONE003','SET001'], location:'Moyna',   qty:60,  unit:'meters',  price:12,  minQty:15 },
            { id:'RM011', name:'Embroidery Thread',       usedIn:['JHA003','KUR001'], location:'Arambagh',         qty:30,  unit:'spools',  price:25,  minQty:8  },
            { id:'RM012', name:'Packaging Box (Small)',   usedIn:['ROM001','ONE002','JHA003'], location:'Howrah-Packaging', qty:100, unit:'pcs', price:5, minQty:25 },
            { id:'RM013', name:'Packaging Box (Large)',   usedIn:['DUN004','KUR001','SET001'], location:'Howrah-Packaging', qty:60, unit:'pcs', price:8, minQty:15 },
            { id:'RM014', name:'Hang Tags & Labels',      usedIn:['ROM001','ROM002','ONE002','ONE003','JHA003','JHA004','DUN004','KUR001','DRS001','SET001'], location:'Howrah-Packaging', qty:300, unit:'pcs', price:1, minQty:50 }
        ];

        // ===== PRODUCTION STAGES =====
        const PROD_STAGES = [
            { id:1, name:'Cutting',    icon:'✂️', location:'Howrah-Cutting',   color:'#e74c3c', bg:'#fdecea' },
            { id:2, name:'Printing',   icon:'🖨️', location:'Dhulagarh',        color:'#e67e22', bg:'#fef3e2' },
            { id:3, name:'Embroidery', icon:'🪡', location:'Arambagh',          color:'#9b59b6', bg:'#f5eef8' },
            { id:4, name:'Stitching',  icon:'🧵', location:'Moyna',             color:'#3498db', bg:'#eaf4fb' },
            { id:5, name:'Packaging',  icon:'📦', location:'Howrah-Packaging',  color:'#27ae60', bg:'#eafaf1' }
        ];

        let productionBatches = [
            { id:'BATCH-001', product:'Cotton Romper',      code:'ROM001', qty:20, currentStage:3, createdDate:'2026-02-15',
              stages:[{s:1,status:'done',date:'2026-02-15',qty:20},{s:2,status:'done',date:'2026-02-17',qty:20},{s:3,status:'in-progress',date:'2026-02-20',qty:18},{s:4,status:'pending',date:null,qty:0},{s:5,status:'pending',date:null,qty:0}] },
            { id:'BATCH-002', product:'Soft Onesie',        code:'ONE002', qty:15, currentStage:4, createdDate:'2026-02-14',
              stages:[{s:1,status:'done',date:'2026-02-14',qty:15},{s:2,status:'done',date:'2026-02-16',qty:15},{s:3,status:'done',date:'2026-02-18',qty:15},{s:4,status:'in-progress',date:'2026-02-20',qty:14},{s:5,status:'pending',date:null,qty:0}] },
            { id:'BATCH-003', product:'Traditional Jhapla', code:'JHA003', qty:10, currentStage:5, createdDate:'2026-02-12',
              stages:[{s:1,status:'done',date:'2026-02-12',qty:10},{s:2,status:'done',date:'2026-02-13',qty:10},{s:3,status:'done',date:'2026-02-15',qty:10},{s:4,status:'done',date:'2026-02-17',qty:10},{s:5,status:'in-progress',date:'2026-02-20',qty:10}] },
            { id:'BATCH-004', product:'Denim Dungarees',    code:'DUN004', qty:12, currentStage:1, createdDate:'2026-02-21',
              stages:[{s:1,status:'in-progress',date:'2026-02-21',qty:12},{s:2,status:'pending',date:null,qty:0},{s:3,status:'pending',date:null,qty:0},{s:4,status:'pending',date:null,qty:0},{s:5,status:'pending',date:null,qty:0}] }
        ]; // bump this to reset products

        function loadSavedProducts() {
            const savedVersion = localStorage.getItem('onekid_products_version');
            const saved = localStorage.getItem('onekid_products');
            if (saved && savedVersion === PRODUCTS_VERSION) {
                products = JSON.parse(saved);
                console.log('✅ Loaded products from storage');
            } else {
                // Version mismatch or first load — use fresh defaults with correct thresholds
                console.log('🔄 Resetting products to latest defaults');
                localStorage.setItem('onekid_products_version', PRODUCTS_VERSION);
                saveProducts(); // save fresh defaults
            }
        }

        // ===== ADMIN TAB SWITCHING =====
        function switchAdminTab(tabId, btn) {
            document.querySelectorAll('.admin-tab-content').forEach(t => t.style.display = 'none');
            document.querySelectorAll('.admin-tab-btn').forEach(b => {
                b.style.background = '#eee';
                b.style.color = '#666';
            });
            document.getElementById(tabId).style.display = 'block';
            if (btn) { btn.style.background = '#ff6b9d'; btn.style.color = 'white'; }
        }

        // ===== RAW MATERIALS FUNCTIONS =====
        function loadRawMaterials() {
            const body = document.getElementById('rawMaterialsBody');
            if (!body) return;
            body.innerHTML = rawMaterials.map((rm, i) => {
                const total = rm.qty * rm.price;
                const isOut = rm.qty === 0;
                const isLow = rm.qty > 0 && rm.qty <= rm.minQty;
                const rowBg = isOut ? 'background:#fff0f0;border-left:4px solid #dc3545;' : isLow ? 'background:#fffbf0;border-left:4px solid #ffc107;' : '';
                const badge = isOut
                    ? '<span style="background:#dc3545;color:white;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;">OUT</span>'
                    : isLow
                    ? '<span style="background:#ffc107;color:#333;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;">⚠️ LOW</span>'
                    : '<span style="background:#28a745;color:white;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:700;">OK</span>';
                const usedNames = rm.usedIn.map(id => {
                    const p = products.find(p => p.id === id);
                    return p ? p.name : id;
                }).join(', ');
                return '<tr style="' + rowBg + '">'
                    + '<td><strong>' + rm.id + '</strong></td>'
                    + '<td>' + rm.name + '</td>'
                    + '<td style="font-size:11px;color:#666;">' + usedNames + '</td>'
                    + '<td>' + rm.location + '</td>'
                    + '<td style="font-weight:700;color:' + (isOut ? '#dc3545' : isLow ? '#e67e22' : '#333') + ';">' + rm.qty + '</td>'
                    + '<td>' + rm.unit + '</td>'
                    + '<td>&#8377;' + rm.price + '</td>'
                    + '<td>&#8377;' + total.toLocaleString('en-IN') + '</td>'
                    + '<td>' + badge + '<br><small style="color:#999;">Min: ' + rm.minQty + '</small></td>'
                    + '<td>'
                    + '<button class="action-btn" onclick="restockRM(' + i + ')" style="font-size:11px;padding:4px 8px;">+Stock</button>'
                    + '<button class="action-btn edit" onclick="deleteRM(' + i + ')" style="font-size:11px;padding:4px 8px;background:#dc3545;border-color:#dc3545;">Del</button>'
                    + '</td>'
                    + '</tr>';
            }).join('');
        }

        function openAddRMModal() {
            const m = document.getElementById('addRMModal');
            m.style.display = 'flex';
        }

        function saveNewRM() {
            const name = document.getElementById('rmName').value.trim();
            const qty = parseInt(document.getElementById('rmQty').value);
            const price = parseFloat(document.getElementById('rmPrice').value);
            const minQty = parseInt(document.getElementById('rmMin').value);
            if (!name || !qty || !price) { showToast('⚠️ Fill all fields'); return; }
            const newId = 'RM' + String(rawMaterials.length + 1).padStart(3, '0');
            rawMaterials.push({
                id: newId, name,
                usedIn: [],
                location: document.getElementById('rmLocation').value,
                qty, unit: document.getElementById('rmUnit').value,
                price, minQty
            });
            closeModal('addRMModal');
            loadRawMaterials();
            showToast('✅ ' + name + ' added to raw materials!');
        }

        function restockRM(idx) {
            const rm = rawMaterials[idx];
            const qty = parseInt(prompt('Add stock for ' + rm.name + ' (current: ' + rm.qty + ' ' + rm.unit + '):', '50'));
            if (!qty || isNaN(qty) || qty < 1) return;
            rm.qty += qty;
            loadRawMaterials();
            showToast('✅ ' + rm.name + ' restocked! Now: ' + rm.qty + ' ' + rm.unit);
        }

        function deleteRM(idx) {
            const rm = rawMaterials[idx];
            if (!confirm('Delete ' + rm.name + ' from raw materials?')) return;
            rawMaterials.splice(idx, 1);
            loadRawMaterials();
            showToast('🗑️ ' + rm.name + ' removed');
        }

        // ===== PRODUCTION BATCH FUNCTIONS =====
        function openNewBatchModal() {
            const sel = document.getElementById('batchProduct');
            sel.innerHTML = '<option value="">-- Select Product --</option>'
                + products.map(p => {
                    const isLow = p.stock <= p.lowStockThreshold;
                    const isOut = p.stock <= 0;
                    const tag = isOut ? ' 🔴 OUT' : isLow ? ' ⚠️ LOW (' + p.stock + ')' : ' ✅ (' + p.stock + ')';
                    return '<option value="' + p.id + '">' + p.name + ' ' + p.size + tag + '</option>';
                }).join('');
            document.getElementById('newBatchModal').style.display = 'flex';
        }

        function createNewBatch() {
            const code = document.getElementById('batchProduct').value;
            const qty = parseInt(document.getElementById('batchQty').value);
            if (!code || !qty || qty < 1) { showToast('⚠️ Select product and quantity'); return; }
            const prod = products.find(p => p.id === code);
            const batchId = 'BATCH-' + String(productionBatches.length + 1).padStart(3, '0');
            const today = new Date().toISOString().split('T')[0];
            productionBatches.push({
                id: batchId, product: prod.name, code, qty, currentStage: 1, createdDate: today,
                stages: [
                    {s:1, status:'in-progress', date:today, qty},
                    {s:2, status:'pending', date:null, qty:0},
                    {s:3, status:'pending', date:null, qty:0},
                    {s:4, status:'pending', date:null, qty:0},
                    {s:5, status:'pending', date:null, qty:0}
                ]
            });
            closeModal('newBatchModal');
            renderProductionBatches();
            showToast('✅ ' + batchId + ' started! Stage 1: Cutting at Howrah', 3000);
        }

        function advanceStage(batchIdx) {
            const batch = productionBatches[batchIdx];
            const stageNames = ['Cutting','Printing','Embroidery','Stitching','Packaging'];
            const stageLocations = ['Howrah-Cutting','Dhulagarh','Arambagh','Moyna','Howrah-Packaging'];
            batch.stages[batch.currentStage - 1].status = 'done';
            if (batch.currentStage < 5) {
                batch.currentStage++;
                const today = new Date().toISOString().split('T')[0];
                batch.stages[batch.currentStage - 1].status = 'in-progress';
                batch.stages[batch.currentStage - 1].date = today;
                batch.stages[batch.currentStage - 1].qty = batch.stages[batch.currentStage - 2].qty;
                showToast('✅ ' + batch.id + ' → Stage ' + batch.currentStage + ': ' + stageNames[batch.currentStage-1] + ' at ' + stageLocations[batch.currentStage-1], 3000);
            }
            renderProductionBatches();
        }

        function completeBatch(batchIdx) {
            const batch = productionBatches[batchIdx];
            batch.stages[4].status = 'done';
            batch.stages[4].date = new Date().toISOString().split('T')[0];
            batch.stages[4].qty = batch.qty;
            const prod = products.find(p => p.id === batch.code);
            if (prod) {
                prod.stock += batch.qty;
                saveProducts();
                updateAdminStats();
                loadInventory();
                loadProducts();
                showToast('🎉 ' + batch.id + ' done! +' + batch.qty + ' ' + batch.product + ' added to stock. New stock: ' + prod.stock, 4000);
            }
            productionBatches.splice(batchIdx, 1);
            renderProductionBatches();
        }

        function renderProductionBatches() {
            const container = document.getElementById('productionBatchCards');
            if (!container) return;
            const stageColors = ['#e74c3c','#e67e22','#9b59b6','#3498db','#27ae60'];
            const stageIcons  = ['✂️','🖨️','🪡','🧵','📦'];
            const stageNames  = ['Cutting','Printing','Embroidery','Stitching','Packaging'];
            const stageLocations = ['Howrah','Dhulagarh','Arambagh','Moyna','Howrah'];

            // Render WIP stage summary
            const wipSummary = document.getElementById('wipStageSummary');
            if (wipSummary) {
                wipSummary.innerHTML = stageNames.map((name, i) => {
                    const batchesHere = productionBatches.filter(b => b.currentStage === i+1);
                    const totalUnits  = batchesHere.reduce((s, b) => s + b.stages[i].qty, 0);
                    const bg = batchesHere.length > 0 ? stageColors[i] : '#f0f0f0';
                    const textColor = batchesHere.length > 0 ? 'white' : '#aaa';
                    return '<div style="background:' + bg + ';color:' + textColor + ';border-radius:10px;padding:10px;text-align:center;">'
                        + '<div style="font-size:1.2rem;">' + stageIcons[i] + '</div>'
                        + '<div style="font-size:11px;font-weight:700;">' + name + '</div>'
                        + '<div style="font-size:10px;opacity:0.85;">' + stageLocations[i] + '</div>'
                        + '<div style="font-size:1.1rem;font-weight:800;margin-top:4px;">' + (batchesHere.length > 0 ? totalUnits + ' pcs' : '—') + '</div>'
                        + '<div style="font-size:10px;opacity:0.8;">' + (batchesHere.length > 0 ? batchesHere.length + ' batch(es)' : 'Idle') + '</div>'
                        + '</div>';
                }).join('');
            }

            if (productionBatches.length === 0) {
                container.innerHTML = '<div style="text-align:center;color:#aaa;padding:40px;background:#f9f9f9;border-radius:12px;">No active batches. Click <strong>+ New Batch</strong> to start production.</div>';
                return;
            }

            container.innerHTML = productionBatches.map((batch, bIdx) => {
                const doneCnt = batch.stages.filter(s => s.status === 'done').length;
                const pct = Math.round((doneCnt / 5) * 100);
                const curColor = stageColors[batch.currentStage - 1];

                const stagesHtml = batch.stages.map((st, i) => {
                    const bg = st.status === 'done' ? stageColors[i] : st.status === 'in-progress' ? stageColors[i] : '#ddd';
                    const border = st.status === 'in-progress' ? 'outline:3px solid ' + stageColors[i] + ';outline-offset:2px;' : '';
                    const icon = st.status === 'done' ? '✅' : stageIcons[i];
                    const divider = i < 4 ? '<div style="flex:1;height:2px;background:' + (st.status === 'done' ? stageColors[i] : '#ddd') + ';min-width:10px;margin-top:25px;"></div>' : '';
                    return '<div style="text-align:center;min-width:70px;">'
                        + '<div style="width:42px;height:42px;border-radius:50%;background:' + bg + ';color:' + (bg === '#ddd' ? '#aaa' : 'white') + ';display:flex;align-items:center;justify-content:center;font-size:1rem;margin:0 auto 4px;' + border + '">' + icon + '</div>'
                        + '<div style="font-size:9px;font-weight:700;color:' + (bg === '#ddd' ? '#bbb' : stageColors[i]) + ';">' + stageNames[i] + '</div>'
                        + (st.status !== 'pending' ? '<div style="font-size:9px;color:#888;">' + st.qty + ' pcs</div>' : '<div style="font-size:9px;color:#ccc;">Pending</div>')
                        + (st.status === 'in-progress' ? '<div style="font-size:8px;font-weight:700;color:' + stageColors[i] + ';">● LIVE</div>' : '')
                        + '</div>' + divider;
                }).join('');

                const actionBtn = batch.currentStage < 5
                    ? '<button onclick="advanceStage(' + bIdx + ')" style="padding:7px 14px;background:' + stageColors[batch.currentStage] + ';color:white;border:none;border-radius:8px;cursor:pointer;font-weight:600;font-size:12px;">→ Move to ' + stageNames[batch.currentStage] + '</button>'
                    : '<button onclick="completeBatch(' + bIdx + ')" style="padding:7px 14px;background:#27ae60;color:white;border:none;border-radius:8px;cursor:pointer;font-weight:600;font-size:12px;">✅ Complete & Add to Stock</button>';

                const prodItem = products.find(p => p.id === batch.code);
                const currentStock = prodItem ? prodItem.stock : 0;
                const threshold    = prodItem ? prodItem.lowStockThreshold : 0;
                const stockColor   = currentStock <= 0 ? '#dc3545' : currentStock <= threshold ? '#e67e22' : '#28a745';
                const stockLabel   = currentStock <= 0 ? 'OUT OF STOCK' : currentStock <= threshold ? 'LOW STOCK' : 'In Stock';

                return '<div style="background:#fafafa;border:1px solid #eee;border-radius:14px;padding:18px;margin-bottom:14px;border-left:5px solid ' + curColor + ';">'
                    + '<div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;margin-bottom:12px;">'
                    + '<div><div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">'
                    + '<strong>' + batch.id + '</strong>'
                    + '<span style="background:' + curColor + ';color:white;padding:2px 10px;border-radius:10px;font-size:11px;">' + stageIcons[batch.currentStage-1] + ' ' + stageNames[batch.currentStage-1] + '</span>'
                    + '<span style="background:' + stockColor + ';color:white;padding:2px 10px;border-radius:10px;font-size:11px;">📦 Stock: ' + currentStock + ' — ' + stockLabel + '</span>'
                    + '</div>'
                    + '<div style="font-size:12px;color:#666;margin-top:4px;">🏷️ ' + batch.product + '  |  Producing: ' + batch.qty + ' units  |  Started: ' + batch.createdDate + '</div>'
                    + '<div style="font-size:11px;color:#888;margin-top:2px;">⚠️ Low stock threshold: ' + threshold + ' units</div>'
                    + '</div>'
                    + '<div style="text-align:right;"><div style="font-size:1.3rem;font-weight:800;color:' + curColor + ';">' + pct + '%</div><div style="font-size:10px;color:#888;">Complete</div></div>'
                    + '</div>'
                    + '<div style="background:#eee;border-radius:8px;height:6px;margin-bottom:14px;"><div style="background:' + curColor + ';height:6px;border-radius:8px;width:' + pct + '%;transition:width 0.5s;"></div></div>'
                    + '<div style="display:flex;align-items:center;overflow-x:auto;padding:4px 0;margin-bottom:14px;">' + stagesHtml + '</div>'
                    + '<div style="text-align:right;">' + actionBtn + '</div>'
                    + '</div>';
            }).join('');
        }

        // Load saved images
        function loadSavedImages() {
            const savedImages = localStorage.getItem('product_images');
            if (savedImages) {
                const images = JSON.parse(savedImages);
                products.forEach(p => {
                    if (images[p.id]) {
                        p.image = images[p.id];
                    }
                });
            }
        }

        // Save images
        function saveImages() {
            const images = {};
            products.forEach(p => {
                if (p.image) images[p.id] = p.image;
            });
            localStorage.setItem('product_images', JSON.stringify(images));
        }

        // ===== AUTHENTICATION =====
        
        function saveApiKey() {
            const key = document.getElementById('apiKeyInput').value.trim();
            if (!key) { showAlert('⚠️ Please paste your Web3Forms access key', 'error'); return; }
            localStorage.setItem('web3forms_api_key', key);
            CONFIG.web3formsKey = key;
            document.getElementById('apiKeySetup').style.display = 'none';
            document.getElementById('credentialFields').style.display = 'block';
            showAlert('✅ Key saved! You can now login.', 'success');
            const w3fStatus = document.getElementById('w3fStatus');
            const w3fBox = document.getElementById('w3fSetupBox');
            if (w3fStatus) { w3fStatus.innerHTML = '✅ Connected'; w3fStatus.style.color = '#28a745'; }
            if (w3fBox) w3fBox.style.borderColor = '#28a745';
        }

        async function sendOTP() {
            const email = document.getElementById('adminEmail').value.trim();
            const password = document.getElementById('adminPassword').value.trim();
            if (password !== CONFIG.adminPassword) { showAlert('❌ Incorrect password', 'error'); return; }
            CONFIG.currentOTP = Math.floor(100000 + Math.random() * 900000).toString();
            CONFIG.otpExpiry = Date.now() + (5 * 60 * 1000);
            const btn = document.getElementById('loginBtn');
            btn.disabled = true;
            btn.innerHTML = '<span class="loading"></span> Sending OTP...';
            try {
                if (CONFIG.web3formsKey) {
                    await sendEmailOTP(email, CONFIG.currentOTP);
                    showAlert('✅ OTP sent! Check your email.', 'success');
                } else {
                    alert('⚠️ Demo Mode - No Web3Forms key set.\nYour OTP is: ' + CONFIG.currentOTP);
                    showAlert('⚠️ Demo: OTP shown in popup above.', 'info');
                }
                document.getElementById('loginForm').classList.add('hide');
                document.getElementById('otpForm').classList.remove('hide');
                document.getElementById('otpEmail').textContent = email;
                for (let i = 1; i <= 6; i++) document.getElementById('otp'+i).value = '';
                startOTPTimer();
                document.getElementById('otp1').focus();
            } catch(err) {
                showAlert('❌ Failed to send OTP. Check Web3Forms key.', 'error');
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-paper-plane"></i> Send OTP to Email';
            }
        }

        async function sendEmailOTP(email, otp) {
            const formData = new FormData();
            formData.append('access_key', CONFIG.web3formsKey);
            formData.append('subject', `OneKid Admin Login - OTP: ${otp}`);
            formData.append('from_name', 'OneKid ERP System');
            formData.append('email', email);
            formData.append('message', `
                <div style="font-family: Arial; max-width: 600px; margin: 0 auto;">
                    <div style="background: linear-gradient(135deg, #ff6b9d, #ff8fab); padding: 30px; text-align: center; border-radius: 15px 15px 0 0;">
                        <h1 style="color: white; margin: 0;">🍼 OneKid ERP</h1>
                    </div>
                    <div style="background: white; padding: 40px; border-radius: 0 0 15px 15px;">
                        <h2 style="color: #ff6b9d;">Your Admin Login Code</h2>
                        <div style="background: linear-gradient(135deg, #ff6b9d, #ff8fab); padding: 25px; border-radius: 12px; text-align: center; margin: 30px 0;">
                            <div style="font-size: 3rem; font-weight: bold; color: white; letter-spacing: 10px;">${otp}</div>
                        </div>
                        <p style="color: #666;">This code expires in 5 minutes.</p>
                        <p style="color: #666; margin-top: 20px;">${CONFIG.businessInfo.name}<br>📞 ${CONFIG.businessInfo.phone} | 📧 ${CONFIG.businessInfo.email}</p>
                    </div>
                </div>
            `);

            const response = await fetch('https://api.web3forms.com/submit', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) throw new Error('Email failed');
            console.log('✅ OTP Email sent successfully');
        }

        function verifyOTP() {
            const otp = Array.from({length: 6}, (_, i) =>
                document.getElementById('otp'+(i+1)).value
            ).join('');
            if (otp.length !== 6) { showAlert('⚠️ Enter complete 6-digit code', 'error'); return; }
            if (Date.now() > CONFIG.otpExpiry) { showAlert('❌ OTP expired. Request a new one.', 'error'); return; }
            if (otp === CONFIG.currentOTP) {
                CONFIG.adminLoggedIn = true;
                document.getElementById('adminLoginModal').classList.remove('active');
                document.getElementById('heroSection').style.display = 'none';
                document.getElementById('shopSection').style.display = 'none';
                document.getElementById('cartSection').classList.add('hide');
                document.getElementById('adminSection').classList.remove('hide');
                document.querySelectorAll('.nav-item').forEach((item, i) => item.classList.toggle('active', i === 3));
                showToast('✅ Admin login successful! Syncing from cloud...', 2500);
                if (!db) initFirebase();
                if (db) {
                    loadOrders().then(() => { loadRawMaterials(); renderProductionBatches(); });
                } else {
                    setTimeout(() => {
                        initFirebase();
                        loadOrders().then(() => { loadRawMaterials(); renderProductionBatches(); });
                    }, 600);
                }
            } else {
                showAlert('❌ Invalid OTP. Try again.', 'error');
            }
        }

        function backToCredentials() {
            document.getElementById('otpForm').classList.add('hide');
            document.getElementById('loginForm').classList.remove('hide');
        }

        function startOTPTimer() {
            let timeLeft = 300;
            const timer = setInterval(() => {
                timeLeft--;
                const mins = Math.floor(timeLeft / 60);
                const secs = timeLeft % 60;
                document.getElementById('timerCount').textContent = 
                    `${mins}:${secs.toString().padStart(2, '0')}`;
                if (timeLeft <= 0) clearInterval(timer);
            }, 1000);
        }

        function logout() {
            if (confirm('Logout from Admin?')) {
                CONFIG.adminLoggedIn = false;
                CONFIG.currentOTP = null;
                showSection('home');
                showToast('👋 Logged out from Admin', 2000);
            }
        }

        // ===== APPLICATION =====
        
        async function initApp() {
            loadSavedProducts();
            loadSavedImages();
            initFirebase(); // connect to Firebase
            await loadOrders(); // load from Firebase or localStorage
            loadProducts();
            updateCartDisplay();
            updateAdminStats();
            console.log('✅ OneKid ERP Initialized');
        }

        function loadProducts(filter = 'all') {
            const filtered = filter === 'all' ? products : products.filter(p => p.category === filter);
            document.getElementById('productGrid').innerHTML = filtered.map(p => {
                const isOut = p.stock <= 0;
                const isLow = p.stock > 0 && p.stock <= p.lowStockThreshold;
                const stockClass = isOut ? 'stock-out' : isLow ? 'stock-low' : 'stock-good';
                const stockText = isOut ? '❌ Out of Stock' : isLow ? `⚠️ Low (${p.stock})` : `✅ In Stock (${p.stock})`;
                
                const imageStyle = p.image 
                    ? `background-image: url(${p.image}); background-size: cover; background-position: center;`
                    : '';
                
                return `
                    <div class="product-card">
                        <div class="product-image" style="${imageStyle}">
                            ${p.image ? '' : p.emoji}
                        </div>
                        <div class="product-info">
                            <div class="product-name">${p.name}</div>
                            <div class="product-details">
                                ${p.size} • ${p.color}<br>
                                ${p.fabric} • ${p.print}
                            </div>
                            <div id="stockBadge_${p.id}" class="stock-badge ${stockClass}">${stockText}</div>
                            <div class="product-price">₹${p.price}</div>
                            <button id="addBtn_${p.id}" class="add-btn" onclick="addToCart('${p.id}')" ${isOut ? 'disabled style="opacity:0.5;cursor:not-allowed;"' : ''}>
                                ${isOut ? '❌ Out of Stock' : '+ Add to Cart'}
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        function filterProducts(cat, btn) {
            loadProducts(cat);
            document.querySelectorAll('.category-tab').forEach(t => t.classList.remove('active'));
            if (btn) btn.classList.add('active');
        }

        function addToCart(id) {
            const product = products.find(p => p.id === id);
            if (!product || product.stock <= 0) { showToast('❌ Out of stock!'); return; }
            const existing  = cart.find(item => item.id === id);
            const inCartQty = existing ? existing.quantity : 0;
            if (inCartQty >= product.stock) { showToast('⚠️ Only ' + product.stock + ' available!'); return; }
            if (existing) { existing.quantity++; }
            else { cart.push({ ...product, quantity: 1 }); }
            updateCartDisplay();
            refreshStockBadge(id);
            const remaining = product.stock - (inCartQty + 1);
            if (remaining === 0) showToast('🔴 Last one! All stock in cart.', 2500);
            else if (remaining <= product.lowStockThreshold) showToast('⚠️ Only ' + remaining + ' more available!', 2500);
            else showToast('✅ Added to cart!');
        }

        function refreshStockBadge(id) {
            const product   = products.find(p => p.id === id);
            if (!product) return;
            const inCart    = cart.find(i => i.id === id);
            const remaining = product.stock - (inCart ? inCart.quantity : 0);
            const badge  = document.getElementById('stockBadge_' + id);
            const card   = document.getElementById('productCard_' + id);
            const btn    = document.getElementById('addBtn_' + id);
            if (!badge) return;
            if (remaining <= 0) {
                badge.className = 'stock-badge stock-out';
                badge.textContent = '❌ Out of Stock';
                if (card) card.style.opacity = '0.65';
                if (btn)  { btn.disabled = true; btn.style.opacity='0.5'; btn.textContent='❌ Out of Stock'; }
            } else if (remaining <= product.lowStockThreshold) {
                badge.className = 'stock-badge stock-low';
                badge.textContent = '⚠️ Only ' + remaining + ' left!';
                if (card) { card.style.opacity='1'; card.style.border='2px solid #ffc107'; }
                if (btn)  { btn.disabled=false; btn.style.opacity='1'; btn.textContent='+ Add to Cart'; }
            } else {
                badge.className = 'stock-badge stock-good';
                badge.textContent = '✅ In Stock (' + remaining + ')';
                if (card) { card.style.opacity='1'; card.style.border=''; }
                if (btn)  { btn.disabled=false; btn.style.opacity='1'; btn.textContent='+ Add to Cart'; }
            }
        }

        function updateCartDisplay() {
            const count = cart.reduce((sum, item) => sum + item.quantity, 0);
            document.getElementById('cartCount').textContent = count;
            
            const cartItems = document.getElementById('cartItems');
            const cartSummary = document.getElementById('cartSummary');
            
            if (cart.length === 0) {
                cartItems.innerHTML = '<div class="empty-state"><i class="fas fa-shopping-cart"></i><p>Cart is empty</p></div>';
                cartSummary.innerHTML = '';
                return;
            }
            
            cartItems.innerHTML = cart.map((item, i) => {
                const imgStyle = item.image 
                    ? `background-image: url(${item.image});`
                    : '';
                    
                return `
                    <div class="cart-item">
                        <div class="cart-item-img" style="${imgStyle}">
                            ${item.image ? '' : item.emoji}
                        </div>
                        <div class="cart-item-info">
                            <div class="cart-item-name">${item.name}</div>
                            <div style="font-size: 12px; color: #666;">${item.size} • ${item.color}</div>
                            <div class="cart-item-price">₹${item.price}</div>
                            <div class="qty-controls">
                                <button class="qty-btn" onclick="updateQty(${i}, -1)">−</button>
                                <div class="qty-value">${item.quantity}</div>
                                <button class="qty-btn" onclick="updateQty(${i}, 1)">+</button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
            
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            const gst = subtotal * 0.05;
            const total = subtotal + gst + 50;
            
            cartSummary.innerHTML = `
                <div class="cart-summary">
                    <div class="summary-row"><span>Subtotal</span><span>₹${subtotal.toFixed(2)}</span></div>
                    <div class="summary-row"><span>GST (5%)</span><span>₹${gst.toFixed(2)}</span></div>
                    <div class="summary-row"><span>Shipping</span><span>₹50.00</span></div>
                    <div class="summary-row summary-total"><span>Total</span><span>₹${total.toFixed(2)}</span></div>
                    <button class="checkout-btn" onclick="openCheckout()">
                        <i class="fas fa-credit-card"></i> Proceed to Checkout
                    </button>
                </div>
            `;
        }

        function updateQty(index, change) {
            const item    = cart[index];
            const product = products.find(p => p.id === item.id);
            const newQty  = item.quantity + change;
            if (newQty < 1) {
                const pid = item.id;
                cart.splice(index, 1);
                updateCartDisplay();
                refreshStockBadge(pid);
                return;
            }
            if (newQty > product.stock) { showToast('⚠️ Only ' + product.stock + ' available!'); return; }
            item.quantity = newQty;
            updateCartDisplay();
            refreshStockBadge(item.id);
            const remaining = product.stock - newQty;
            if (remaining === 0) showToast('🔴 All stock in cart!', 2500);
            else if (remaining <= product.lowStockThreshold) showToast('⚠️ Only ' + remaining + ' more available!', 2000);
        }

        function openCheckout() {
            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            const gst = subtotal * 0.05;
            const total = subtotal + gst + 50;
            
            document.getElementById('checkoutSummary').innerHTML = `
                <div style="background: #f8f9fa; padding: 15px; border-radius: 10px;">
                    ${cart.map(item => `
                        <div style="display: flex; justify-content: space-between; margin: 5px 0;">
                            <span>${item.name} x${item.quantity}</span>
                            <span>₹${(item.price * item.quantity).toFixed(2)}</span>
                        </div>
                    `).join('')}
                    <div style="border-top: 2px solid #ff6b9d; margin-top: 10px; padding-top: 10px; font-weight: bold; color: #ff6b9d;">
                        <div style="display: flex; justify-content: space-between;">
                            <span>Total:</span><span>₹${total.toFixed(2)}</span>
                        </div>
                    </div>
                </div>
            `;
            document.getElementById('checkoutModal').classList.add('active');
        }

        async function placeOrder(e) {
            e.preventDefault();
            const form = e.target;
            const submitBtn = form.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="loading"></span> Processing Order...';

            const formData = new FormData(form);
            const orderId = `MC-${orderCounter++}`;

            const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
            const gst = subtotal * 0.05;
            const total = subtotal + gst + 50;

            const order = {
                orderId,
                date: new Date().toLocaleDateString('en-IN'),
                time: new Date().toLocaleTimeString('en-IN'),
                customer: formData.get('name'),
                email:    formData.get('email'),
                phone:    formData.get('phone'),
                address:  formData.get('address'),
                payment:  formData.get('payment'),
                items: [...cart],
                subtotal, gst, total
            };

            // Update inventory
            cart.forEach(item => {
                const product = products.find(p => p.id === item.id);
                if (product) product.stock = Math.max(0, product.stock - item.quantity);
            });
            saveProducts();

            orders.push(order);
            saveOrders(); // local backup immediately
            saveProducts();

            // ---- Save to Firebase (cloud) ----
            if (db) {
                saveOrderToFirebase(order).then(ok => {
                    if (ok) console.log('☁️ Order synced to cloud');
                });
            }

            // ---- Live table update (instant) ----
            renderOrderTables();
            updateAdminStats();

            // ---- Email to customer ----
            let emailSent = false;
            window.__lastCustomerEmailError = '';
            if (CONFIG.emailjsServiceId && CONFIG.emailjsTemplateId && CONFIG.emailjsPublicKey) {
                try {
                    await sendOrderEmailToCustomer(order);
                    emailSent = true;
                    console.log('✅ Customer email sent');
                } catch(err) {
                    window.__lastCustomerEmailError = err && err.message ? err.message : String(err);
                    console.warn('⚠️ Customer email failed:', window.__lastCustomerEmailError, err);
                }
            } else {
                window.__lastCustomerEmailError = 'EmailJS is not configured. Add Service ID, Template ID and Public Key in Integration Setup.';
            }
            // Admin order notification is independent of the customer's EmailJS confirmation.
            if (CONFIG.web3formsKey) {
                try {
                    await sendOrderEmailToAdmin(order);
                    console.log('✅ Admin notification sent');
                } catch(err) {
                    console.warn('⚠️ Admin email failed:', err);
                }
            }

            cart = [];
            closeModal('checkoutModal');
            updateCartDisplay();
            loadProducts();

            form.reset();

            // Show order confirmation popup (stays visible until user clicks Done)
            showOrderConfirmation(order, emailSent);
            submitBtn.disabled = false;
            submitBtn.innerHTML = '<i class="fas fa-check-circle"></i> Place Order';
        }

        // ---- Send confirmation email to CUSTOMER via EmailJS ----
        async function sendOrderEmailToCustomer(order) {
            if (!CONFIG.emailjsServiceId || !CONFIG.emailjsTemplateId || !CONFIG.emailjsPublicKey) {
                // Fallback: use Web3Forms to notify admin that customer needs email
                console.warn('EmailJS not configured — customer email skipped');
                throw new Error('EmailJS not configured');
            }

            const itemLines = order.items.map((item, i) =>
                (i+1) + '. ' + item.name + ' (Size: ' + item.size + ')   Qty: ' + item.quantity + '   Rs.' + (item.price * item.quantity).toFixed(2)
            ).join('\n');

            emailjs.init(CONFIG.emailjsPublicKey);

            const templateParams = {
                to_name:    order.customer,
                to_email:   order.email,
                order_id:   order.orderId,
                order_date: order.date,
                order_time: order.time,
                items_list: itemLines,
                subtotal:   'Rs.' + order.subtotal.toFixed(2),
                gst:        'Rs.' + order.gst.toFixed(2),
                shipping:   'Rs.50.00',
                total:      'Rs.' + order.total.toFixed(2),
                address:    order.address,
                phone:      CONFIG.businessInfo.phone,
                admin_email: CONFIG.businessInfo.email,
                admin_address: CONFIG.businessInfo.address
            };

            if (!window.emailjs || typeof emailjs.send !== 'function') {
                throw new Error('EmailJS library did not load. Check internet connection or browser console.');
            }
            const res = await emailjs.send(CONFIG.emailjsServiceId, CONFIG.emailjsTemplateId, templateParams);
            if (!res || res.status !== 200) throw new Error('EmailJS failed: ' + (res && res.text ? res.text : 'No successful response'));
        }

        // ---- Send notification email to ADMIN ----
        async function sendOrderEmailToAdmin(order) {
            const itemLines = order.items.map((item, idx) =>
                (idx+1) + '. ' + item.name + ' (Size: ' + item.size + ')' +
                '  Qty:' + item.quantity + '  =  Rs.' + (item.price * item.quantity).toFixed(2)
            ).join('\n');

            const msg =
'NEW ORDER RECEIVED\n\n' +
'============================================\n' +
'CUSTOMER DETAILS\n' +
'============================================\n' +
'Name    : ' + order.customer + '\n' +
'Phone   : ' + order.phone + '\n' +
'Email   : ' + order.email + '\n' +
'Address : ' + order.address + '\n\n' +
'============================================\n' +
'ORDER: ' + order.orderId + '\n' +
'============================================\n' +
'Date    : ' + order.date + ' at ' + order.time + '\n' +
'Payment : Cash on Delivery\n\n' +
itemLines + '\n\n' +
'--------------------------------------------\n' +
'TOTAL   : Rs.' + order.total.toFixed(2) + '\n' +
'--------------------------------------------\n\n' +
'Login to OneKid ERP to manage this order.';

            const fd = new FormData();
            fd.append('access_key', CONFIG.web3formsKey);
            fd.append('subject', 'New Order ' + order.orderId + ' from ' + order.customer + ' | OneKid ERP');
            fd.append('from_name', 'OneKid ERP System');
            fd.append('email', CONFIG.adminEmail);
            fd.append('message', msg);
            const res = await fetch('https://api.web3forms.com/submit', { method: 'POST', body: fd });
            const data = await res.json();
            if (!data.success) throw new Error('Admin email failed');
        }

        // ===== ADMIN FUNCTIONS =====
        
        function updateAdminStats() {
            // Orders & Revenue
            const totalOrdersEl = document.getElementById('totalOrders');
            const totalRevenueEl = document.getElementById('totalRevenue');
            const totalStockEl = document.getElementById('totalStock');
            const lowStockEl = document.getElementById('lowStockCount');
            if (!lowStockEl) return; // admin section not visible yet

            totalOrdersEl.textContent = orders.length;
            const revenue = orders.reduce((sum, o) => sum + o.total, 0);
            totalRevenueEl.textContent = '₹' + revenue.toFixed(0);
            const totalStock = products.reduce((sum, p) => sum + p.stock, 0);
            totalStockEl.textContent = totalStock;

            // Low stock calculation
            const outOfStock    = products.filter(p => p.stock <= 0);
            const lowStockItems = products.filter(p => p.stock > 0 && p.stock <= p.lowStockThreshold);
            const alertCount    = outOfStock.length + lowStockItems.length;

            lowStockEl.textContent = alertCount;

            // Color the stat card
            const statCard = lowStockEl.closest('.stat-card');
            if (statCard) {
                if (outOfStock.length > 0) {
                    statCard.style.cssText = 'background:linear-gradient(135deg,#ff4757,#ff6b81);border-radius:15px;padding:25px;';
                    statCard.querySelectorAll('.stat-value,.stat-label,.stat-icon,.stat-icon i').forEach(el => el.style.color = 'white');
                } else if (lowStockItems.length > 0) {
                    statCard.style.cssText = 'background:linear-gradient(135deg,#ffa502,#ff6348);border-radius:15px;padding:25px;';
                    statCard.querySelectorAll('.stat-value,.stat-label,.stat-icon,.stat-icon i').forEach(el => el.style.color = 'white');
                } else {
                    statCard.style.cssText = '';
                    statCard.querySelectorAll('.stat-value,.stat-label,.stat-icon,.stat-icon i').forEach(el => el.style.color = '');
                }
            }

            // Live alert banner — always above stat cards
            let banner = document.getElementById('lowStockBanner');
            if (alertCount > 0) {
                if (!banner) {
                    banner = document.createElement('div');
                    banner.id = 'lowStockBanner';
                    banner.style.cssText = 'border-radius:12px;padding:16px 20px;margin-bottom:20px;font-size:13px;line-height:2.2;';
                    const statCards = document.querySelector('.stat-cards');
                    if (statCards) statCards.parentNode.insertBefore(banner, statCards);
                }
                const outLines   = outOfStock.map(p =>
                    '<div style="display:flex;align-items:center;gap:8px;"><span style="background:#dc3545;color:white;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700;">OUT</span><span><strong>' + p.name + '</strong> (' + p.size + ') — 0 units left — Restock immediately!</span></div>'
                );
                const lowLines   = lowStockItems.map(p =>
                    '<div style="display:flex;align-items:center;gap:8px;"><span style="background:#ffc107;color:#333;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:700;">LOW</span><span><strong>' + p.name + '</strong> (' + p.size + ') — Only <strong>' + p.stock + '</strong> left (restock below ' + p.lowStockThreshold + ')</span></div>'
                );
                const bgColor    = outOfStock.length > 0 ? 'background:#fff0f0;border:2px solid #dc3545;' : 'background:#fffbf0;border:2px solid #ffc107;';
                banner.style.cssText = 'border-radius:12px;padding:16px 20px;margin-bottom:20px;font-size:13px;line-height:2.2;' + bgColor;
                banner.innerHTML =
                    '<div style="font-weight:700;font-size:14px;margin-bottom:10px;color:' + (outOfStock.length > 0 ? '#dc3545' : '#856404') + ';">' +
                    '⚠️ Stock Alert — ' + alertCount + ' product(s) need your attention</div>' +
                    outLines.join('') + lowLines.join('');
                banner.style.display = 'block';
            } else {
                if (banner) banner.style.display = 'none';
            }

            loadInventory();
            renderOrderTables();
        }

        // Auto-refresh admin stats every 30 seconds when admin is open
        setInterval(() => {
            if (CONFIG.adminLoggedIn) {
                loadOrders();
            }
        }, 30000);

        function loadInventory() {
            document.getElementById('inventoryBody').innerHTML = products.map(p => {
                const isOut = p.stock <= 0;
                const isLow = p.stock > 0 && p.stock <= p.lowStockThreshold;
                const color = isOut ? '#dc3545' : isLow ? '#ffc107' : '#28a745';
                
                const imgHtml = p.image 
                    ? `<img src="${p.image}" class="image-preview" onclick="viewImage('${p.image}')">`
                    : `<div style="font-size: 2rem;">${p.emoji}</div>`;
                
                const rowBg = isOut ? 'background:#fff0f0;border-left:4px solid #dc3545;' : isLow ? 'background:#fffbf0;border-left:4px solid #ffc107;' : '';
                return `
                    <tr style="${rowBg}">
                        <td>${imgHtml}</td>
                        <td><strong>${p.id}</strong></td>
                        <td>
                            ${p.name}
                            ${isOut ? '<span style="background:#dc3545;color:white;font-size:10px;padding:2px 6px;border-radius:10px;margin-left:4px;">OUT</span>' : ''}
                            ${isLow ? '<span style="background:#ffc107;color:#333;font-size:10px;padding:2px 6px;border-radius:10px;margin-left:4px;">LOW</span>' : ''}
                        </td>
                        <td style="color: ${color}; font-weight: bold;">
                            ${p.stock}
                            ${isLow && !isOut ? '<div style="font-size:10px;color:#856404;">Threshold: ' + p.lowStockThreshold + '</div>' : ''}
                            ${isOut ? '<div style="font-size:10px;color:#dc3545;">Restock needed</div>' : ''}
                        </td>
                        <td>${p.fabric}</td>
                        <td>${p.print}</td>
                        <td>₹${p.price}</td>
                        <td>
                            <button class="action-btn edit" onclick="openEditProduct('${p.id}')">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="action-btn" onclick="openRestock('${p.id}')">
                                <i class="fas fa-plus"></i> Stock
                            </button>
                            <button class="action-btn image" onclick="openImageUpload('${p.id}')">
                                <i class="fas fa-camera"></i>
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        function openRestock(productId) {
            currentRestockProductId = productId;
            const product = products.find(p => p.id === productId);
            
            document.getElementById('restockProductName').textContent = product.name;
            document.getElementById('restockCurrentStock').textContent = product.stock;
            document.getElementById('restockQuantity').value = '50';
            
            document.getElementById('restockModal').classList.add('active');
        }

        function confirmRestock() {
            const qty = parseInt(document.getElementById('restockQuantity').value);
            
            if (!qty || qty < 1) {
                showToast('⚠️ Please enter valid quantity');
                return;
            }
            
            const product = products.find(p => p.id === currentRestockProductId);
            const oldStock = product.stock;
            product.stock += qty;
            
            closeModal('restockModal');
            updateAdminStats();
            loadProducts();
            
            showToast('✅ ' + product.name + ' restocked! ' + oldStock + ' → ' + product.stock, 3000);
            updateAdminStats();
            loadProducts();
            console.log(`📦 RESTOCKED: ${product.name} +${qty} = ${product.stock} total`);
        }

        function openImageUpload(productId) {
            currentUploadProductId = productId;
            const product = products.find(p => p.id === productId);
            
            document.getElementById('uploadProductName').textContent = product.name;
            document.getElementById('imagePreviewContainer').innerHTML = '';
            document.getElementById('imageInput').value = '';
            
            document.getElementById('imageUploadModal').classList.add('active');
        }

        function previewImage(event) {
            const file = event.target.files[0];
            
            if (!file) return;
            
            // Check file size (5MB limit)
            if (file.size > 5 * 1024 * 1024) {
                showToast('⚠️ Image too large. Max 5MB');
                return;
            }
            
            // Check file type
            if (!file.type.startsWith('image/')) {
                showToast('⚠️ Please upload an image file');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = `
                    <div style="text-align: center;">
                        <img src="${e.target.result}" class="uploaded-image">
                        <p style="margin-top: 10px; color: #28a745; font-weight: 600;">
                            <i class="fas fa-check-circle"></i> Image ready to upload
                        </p>
                    </div>
                `;
                document.getElementById('imagePreviewContainer').innerHTML = preview;
                
                // Store the base64 data temporarily
                window.tempImageData = e.target.result;
            };
            reader.readAsDataURL(file);
        }

        function saveProductImage() {
            if (!window.tempImageData) {
                showToast('⚠️ Please select an image first');
                return;
            }
            
            const product = products.find(p => p.id === currentUploadProductId);
            product.image = window.tempImageData;
            
            // Save to localStorage
            saveImages();
            
            closeModal('imageUploadModal');
            loadProducts();
            updateAdminStats();
            
            showToast(`✅ Image uploaded for ${product.name}!`, 3000);
            console.log(`📸 Image uploaded for: ${product.name}`);
            
            // Clear temp data
            window.tempImageData = null;
        }

        function viewImage(imageSrc) {
            const modal = document.createElement('div');
            modal.className = 'modal active';
            modal.style.zIndex = '3000';
            modal.innerHTML = `
                <div class="modal-content" style="max-width: 800px;">
                    <div class="modal-header">
                        <div class="modal-title">Product Image</div>
                        <button class="close-btn" onclick="this.closest('.modal').remove()">&times;</button>
                    </div>
                    <img src="${imageSrc}" style="width: 100%; border-radius: 12px;">
                </div>
            `;
            document.body.appendChild(modal);
            
            modal.onclick = (e) => {
                if (e.target === modal) modal.remove();
            };
        }

        function openGPS() {
            const coords = CONFIG.businessInfo.gpsCoords;
            const address = encodeURIComponent(CONFIG.businessInfo.address);
            const url = `https://www.google.com/maps/search/?api=1&query=${coords}`;
            window.open(url, '_blank');
        }

        // ===== ORDER PERSISTENCE (Firebase + localStorage fallback) =====
        async function saveOrders() {
            // Always save locally as backup
            localStorage.setItem('onekid_orders', JSON.stringify(orders));
            localStorage.setItem('onekid_order_counter', orderCounter.toString());
        }

          async function saveOrderToFirebase(order) {
            try {
                await fsSet('orders', order.orderId, {
                    orderId: order.orderId, date: order.date, time: order.time,
                    customer: order.customer, email: order.email, phone: order.phone,
                    address: order.address, payment: order.payment,
                    subtotal: order.subtotal, gst: order.gst, total: order.total,
                    items: order.items, createdAt: new Date().toISOString()
                });
                await fsSet('meta', 'counter', { orderCounter });
                console.log('✅ Order saved to Firebase:', order.orderId);
                return true;
            } catch(e) {
                console.warn('❌ Firebase save failed:', e);
                return false;
            }
        }

        async function loadOrders() {
            try {
                const fbOrders = await fsList('orders');
                fbOrders.sort((a,b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
                if (fbOrders.length > 0) {
                    orders = fbOrders;
                    localStorage.setItem('onekid_orders', JSON.stringify(orders));
                    console.log('✅ Orders loaded from Firebase:', orders.length);
                } else if (orders.length === 0) {
                    const saved = localStorage.getItem('onekid_orders');
                    if (saved) orders = JSON.parse(saved);
                    console.log('ℹ️ Firebase returned 0 orders, using localStorage:', orders.length);
                }
                const meta = await fsGet('meta', 'counter');
                if (meta && meta.orderCounter) orderCounter = Number(meta.orderCounter);
            } catch(e) {
                const msg = e.message || String(e);
                console.error('❌ Firebase error:', msg);
                // Show error hint in admin UI
                const masterBody = document.getElementById('orderMasterBody');
                if (masterBody && orders.length === 0) {
                    masterBody.innerHTML = '<tr><td colspan="8" style="text-align:center;padding:20px;color:#dc3545;">⚠️ Firebase error: ' + msg + '<br><small style="color:#888;">Fix: Go to Firebase Console → Firestore → Rules → set <code>allow read, write: if true;</code></small></td></tr>';
                }
                // Fallback to localStorage
                const saved = localStorage.getItem('onekid_orders');
                if (saved) { const local = JSON.parse(saved); if (local.length > 0) { orders = local; console.log('📦 Using localStorage orders:', orders.length); } }
                const counter = localStorage.getItem('onekid_order_counter');
                if (counter) orderCounter = parseInt(counter);
            }
            renderOrderTables();
            updateAdminStats();
        }

        // ===== ORDER TABLES =====
        function renderOrderTables() {
            const masterBody = document.getElementById('orderMasterBody');
            const itemsBody = document.getElementById('orderItemsBody');
            if (!masterBody || !itemsBody) return;

            if (orders.length === 0) {
                masterBody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;padding:20px;">No orders yet. Orders will appear here live after checkout.</td></tr>';
                itemsBody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:#999;padding:20px;">No order items yet. Items will appear here live after checkout.</td></tr>';
                return;
            }

            masterBody.innerHTML = orders.map(o => `
                <tr>
                    <td><strong style="color:#ff6b9d;">${o.orderId}</strong></td>
                    <td>${o.customer}</td>
                    <td>${o.phone}</td>
                    <td>${o.email}</td>
                    <td style="max-width:150px;font-size:12px;">${o.address}</td>
                    <td><span style="background:#e8f5e9;color:#2e7d32;padding:3px 8px;border-radius:10px;font-size:12px;font-weight:600;">${o.payment}</span></td>
                    <td style="font-size:12px;">${o.date} ${o.time}</td>
                    <td style="font-weight:bold;color:#ff6b9d;">₹${o.total.toFixed(2)}</td>
                </tr>
            `).join('');

            let rows = [];
            orders.forEach(o => {
                o.items.forEach((item, idx) => {
                    const sellingPrice = item.price;
                    const totalPrice = sellingPrice * item.quantity;
                    rows.push(`
                        <tr>
                            <td><strong style="color:#ff6b9d;">${o.orderId}</strong></td>
                            <td style="text-align:center;">${idx + 1}</td>
                            <td><strong>${item.id}</strong></td>
                            <td>${item.name}</td>
                            <td style="text-align:center;font-weight:bold;">${item.quantity}</td>
                            <td>₹${sellingPrice.toFixed(2)} <span style="font-size:11px;color:#888;">(incl. 5% GST)</span></td>
                            <td style="font-weight:bold;color:#28a745;">₹${totalPrice.toFixed(2)}</td>
                        </tr>
                    `);
                });
            });
            itemsBody.innerHTML = rows.join('');
        }




        // ===== INTEGRATION SETUP (Admin panel) =====
        function toggleEmailJSSetup() {
            const f = document.getElementById('emailjsSetupForm');
            if (f) f.style.display = f.style.display === 'none' ? 'block' : 'none';
        }

        function saveEmailJSConfig() {
            const svc  = document.getElementById('emailjsServiceInput').value.trim();
            const tmpl = document.getElementById('emailjsTemplateInput').value.trim();
            const pub  = document.getElementById('emailjsPublicInput').value.trim();
            const msg  = document.getElementById('emailjsSaveMsg');
            if (!svc || !tmpl || !pub) {
                msg.innerHTML = '<span style="color:#dc3545;">⚠️ Please fill all three fields</span>';
                return;
            }
            localStorage.setItem('emailjs_service_id',  svc);
            localStorage.setItem('emailjs_template_id', tmpl);
            localStorage.setItem('emailjs_public_key',  pub);
            CONFIG.emailjsServiceId  = svc;
            CONFIG.emailjsTemplateId = tmpl;
            CONFIG.emailjsPublicKey  = pub;
            emailjs.init(pub);
            document.getElementById('emailjsStatus').innerHTML = '✅ Configured — test with an order';
            document.getElementById('emailjsStatus').style.color = '#28a745';
            document.getElementById('emailjsSetupBox').style.borderColor = '#28a745';
            document.getElementById('emailjsSetupForm').style.display = 'none';
            msg.innerHTML = '<span style="color:#28a745;">✅ EmailJS settings saved. Send a test order to verify delivery.</span>';
            showToast('📧 EmailJS settings saved. Verify with a test order.', 3000);
        }

        function toggleW3FSetup() {
            const f = document.getElementById('w3fSetupForm');
            if (f) f.style.display = f.style.display === 'none' ? 'block' : 'none';
        }


        function saveAdminApiKey() {
            const key = document.getElementById('adminApiKeyInput') && document.getElementById('adminApiKeyInput').value.trim();
            if (!key) { showToast('⚠️ Please enter your Web3Forms key'); return; }
            localStorage.setItem('web3forms_api_key', key);
            CONFIG.web3formsKey = key;
            const status = document.getElementById('w3fStatus');
            const box    = document.getElementById('w3fSetupBox');
            const form   = document.getElementById('w3fSetupForm');
            const msg    = document.getElementById('w3fSaveMsg');
            if (status) { status.innerHTML = '✅ Connected'; status.style.color = '#28a745'; }
            if (box)    box.style.borderColor = '#28a745';
            if (form)   form.style.display = 'none';
            if (msg)    msg.innerHTML = '<span style="color:#28a745;">✅ Saved!</span>';
            showToast('✅ Email integration activated!', 2500);
        }


        // ===== EDIT PRODUCT =====
        function openEditProduct(productId) {
            currentEditProductId = productId;
            const product = products.find(p => p.id === productId);
            if (!product) return;
            document.getElementById('editProductName').value  = product.name;
            document.getElementById('editProductPrice').value = product.price;
            document.getElementById('editProductStock').value = product.stock;
            document.getElementById('editProductThreshold').value = product.lowStockThreshold;
            document.getElementById('editProductModal').classList.add('active');
        }

        function saveProductEdit() {
            const product = products.find(p => p.id === currentEditProductId);
            if (!product) return;
            const price     = parseInt(document.getElementById('editProductPrice').value);
            const stock     = parseInt(document.getElementById('editProductStock').value);
            const threshold = parseInt(document.getElementById('editProductThreshold').value);
            if (isNaN(price) || isNaN(stock) || isNaN(threshold)) {
                showToast('⚠️ Please fill all fields'); return;
            }
            product.price = price;
            product.stock = stock;
            product.lowStockThreshold = threshold;
            saveProducts();
            closeModal('editProductModal');
            updateAdminStats();
            loadProducts();
            showToast('✅ ' + product.name + ' updated!', 2500);
        }


        function showOrderConfirmation(order, emailSent) {
            currentConfirmOrder = order;
            document.getElementById('confirmOrderId').textContent = order.orderId;

            const itemsList = order.items.map(item =>
                '<div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid #f0f0f0;">' +
                '<span>' + item.name + ' × ' + item.quantity + '</span>' +
                '<span style="font-weight:600;">₹' + (item.price * item.quantity).toFixed(2) + '</span>' +
                '</div>'
            ).join('');

            document.getElementById('confirmOrderDetails').innerHTML =
                '<div style="margin-bottom:10px;">' +
                '<strong>Customer:</strong> ' + order.customer + '<br>' +
                '<strong>Phone:</strong> ' + order.phone + '<br>' +
                '<strong>Email:</strong> ' + order.email + '<br>' +
                '<strong>Address:</strong> ' + order.address + '<br>' +
                '<strong>Payment:</strong> Cash on Delivery<br>' +
                '<strong>Date:</strong> ' + order.date + ' ' + order.time +
                '</div>' +
                '<div style="border-top:2px solid #ff6b9d;padding-top:10px;margin-top:5px;">' +
                itemsList +
                '<div style="display:flex;justify-content:space-between;padding:8px 0 0;font-weight:700;color:#ff6b9d;font-size:15px;">' +
                '<span>Total</span><span>₹' + order.total.toFixed(2) + '</span>' +
                '</div></div>';

            let emailMsg = '📧 Confirmation email sent to ' + order.email;
            if (!emailSent) {
                const reason = window.__lastCustomerEmailError || 'Email service rejected the request. Check EmailJS configuration.';
                emailMsg = '⚠️ Order placed successfully, but confirmation email was not sent. ' + reason;
            }
            document.getElementById('confirmEmailStatus').textContent = emailMsg;

            document.getElementById('orderConfirmModal').classList.add('active');
        }


        function closeOrderConfirm() {
            document.getElementById('orderConfirmModal').classList.remove('active');
            showSection('home');
        }

        function sendWhatsApp(order) {
            if (!order) return;
            const phone = order.phone.replace(/[^0-9]/g, '').slice(-10);
            const items = order.items.map(i => '• ' + i.name + ' x' + i.quantity + ' = Rs.' + (i.price * i.quantity).toFixed(0)).join('\n');
            const msg = `Hello ${order.customer}! 🎉\n\nYour *OneKid by Mohini Creations* order is confirmed!\n\n*Order ID:* ${order.orderId}\n*Date:* ${order.date}\n\n*Items:*\n${items}\n\n*Total:* Rs.${order.total.toFixed(0)}\n*Payment:* Cash on Delivery\n*Address:* ${order.address}\n\nWe will call before dispatch. Thank you for shopping! 🛍️\n— OneKid, Mohini Creations`;
            window.open('https://wa.me/91' + phone + '?text=' + encodeURIComponent(msg), '_blank');
        }


        function toggleFirebaseSetup() { /* permanently connected */ }

        async function saveFirebaseConfig() { /* permanently connected — onekid-8d0ec */ }

        // ===== NAVIGATION =====
        
        function showSection(section) {
            if (section === 'admin' && !CONFIG.adminLoggedIn) {
                openAdminLoginModal();
                return;
            }
            document.getElementById('heroSection').style.display = section === 'home' ? 'block' : 'none';
            document.getElementById('shopSection').style.display = section === 'shop' || section === 'home' ? 'block' : 'none';
            document.getElementById('cartSection').classList.toggle('hide', section !== 'cart');
            document.getElementById('adminSection').classList.toggle('hide', section !== 'admin');
            const contactEl = document.getElementById('contactSection');
            if (contactEl) contactEl.classList.toggle('hide', section !== 'contact');
            document.querySelectorAll('.nav-item').forEach((item, i) => {
                const sections = ['home', 'shop', 'cart', 'admin'];
                item.classList.toggle('active', sections[i] === section);
            });
            if (section === 'cart') updateCartDisplay();
            if (section === 'admin') updateAdminStats();
        }

        function openAdminLoginModal() {
            document.getElementById('loginForm').classList.remove('hide');
            document.getElementById('otpForm').classList.add('hide');
            document.getElementById('alertContainer').innerHTML = '';
            document.getElementById('adminPassword').value = '';
            for (let i = 1; i <= 6; i++) { const el = document.getElementById('otp'+i); if(el) el.value=''; }
            if (!CONFIG.web3formsKey) {
                document.getElementById('apiKeySetup').style.display = 'block';
                document.getElementById('credentialFields').style.display = 'none';
            } else {
                document.getElementById('apiKeySetup').style.display = 'none';
                document.getElementById('credentialFields').style.display = 'block';
            }
            document.getElementById('adminLoginModal').classList.add('active');
        }

        function closeModal(modalId) {
            const el = document.getElementById(modalId);
            if (!el) return;
            el.classList.remove('active');
            el.style.display = 'none';
        }

        function showAlert(msg, type) {
            const div = document.createElement('div');
            div.className = `alert alert-${type}`;
            div.innerHTML = `<i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'times' : 'info'}-circle"></i><span>${msg}</span>`;
            document.getElementById('alertContainer').innerHTML = '';
            document.getElementById('alertContainer').appendChild(div);
            setTimeout(() => div.remove(), 4000);
        }

        function showToast(msg, duration = 2000) {
            const toast = document.createElement('div');
            toast.className = 'toast';
            toast.textContent = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), duration);
        }

        // ===== OTP INPUT NAVIGATION =====
        
        function initOTPInputs() {
            document.querySelectorAll('#otpForm .otp-input').forEach((input, i, arr) => {
                input.addEventListener('input', (e) => {
                    e.target.value = e.target.value.replace(/[^0-9]/g, '');
                    if (e.target.value && i < arr.length - 1) arr[i + 1].focus();
                });
                input.addEventListener('keydown', (e) => {
                    if (e.key === 'Backspace' && !e.target.value && i > 0) arr[i - 1].focus();
                });
            });
        }

        // ===== INITIALIZATION =====
        
        window.addEventListener('DOMContentLoaded', () => {
            // App loads directly — admin section requires login modal
            initApp();
            initOTPInputs();

            // EmailJS already hardcoded — init immediately
            emailjs.init('VNEA1OWpm07aAe5gw');
            const ejsStatus = document.getElementById('emailjsStatus');
            const ejsBox    = document.getElementById('emailjsSetupBox');
            if (ejsStatus) { ejsStatus.innerHTML = '✅ Connected'; ejsStatus.style.color = '#28a745'; }
            if (ejsBox)    ejsBox.style.borderColor = '#28a745';

            // Set Firebase status badge
            const fbCfg = localStorage.getItem('onekid_firebase_config');
            const fbStatus = document.getElementById('firebaseStatus');
            const fbBox    = document.getElementById('firebaseSetupBox');
            if (fbCfg && db) {
                if (fbStatus) { fbStatus.innerHTML = '✅ Connected'; fbStatus.style.color = '#28a745'; }
                if (fbBox)    fbBox.style.borderColor = '#28a745';
            } else {
                if (fbStatus) { fbStatus.innerHTML = '⚠️ Not configured — click Configure'; fbStatus.style.color = '#dc3545'; }
            }

            // Set integration status badges
            const w3fStatus = document.getElementById('w3fStatus');
            const w3fBox     = document.getElementById('w3fSetupBox');

            if (CONFIG.web3formsKey) {
                if (w3fStatus) { w3fStatus.innerHTML = '✅ Connected'; w3fStatus.style.color = '#28a745'; }
                if (w3fBox)    { w3fBox.style.borderColor = '#28a745'; }
            } else {
                if (w3fStatus) { w3fStatus.innerHTML = '⚠️ Not configured — click Configure'; w3fStatus.style.color = '#dc3545'; }
                if (w3fBox)    { w3fBox.style.borderColor = '#ffc107'; }
            }

            console.log('✅ OneKid ERP v8 Ready');
            console.log('📧 Email: ' + (CONFIG.web3formsKey ? 'Active' : 'Setup Required'));
        });

        // Close modals on outside click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('active');
                }
            });
        });
