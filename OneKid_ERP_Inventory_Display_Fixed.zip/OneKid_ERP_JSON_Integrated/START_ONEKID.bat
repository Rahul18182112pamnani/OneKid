@echo off
title OneKid ERP - Local Backend
cd /d "%~dp0backend"
echo Starting OneKid ERP backend...
echo Open http://localhost:5000 after the server starts.
echo Keep this window open while using the application.
npm start
pause
