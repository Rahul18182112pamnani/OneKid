# OneKid ERP — Local Node.js + JSON database

## Important architecture note
This version does **not** use Firebase or Firestore. The application stores its operational data in `backend/data/db.json` and exposes it through a Node.js HTTP REST API. Firebase is optional and is not needed for Vendor Master, Inventory, Raw Materials, Production, Orders or Purchase Orders.

## Start the application
1. Install Node.js 18 or newer.
2. On Windows, double-click `START_ONEKID.bat` in the project root, or open a terminal in the `backend` folder.
3. If using the terminal, run `npm start`.
4. Open **http://localhost:5000** in your browser. Do not open `index.html` directly and do not use Live Server on port 5500.
5. The Integration Setup card should report **Connected — local JSON database** and show the table counts.

No `npm install` is required; the backend uses Node.js built-ins only.

## Local development admin login
- Email: `rahulpamnani2001@gmail.com`
- Password: `OneKidDemo@2026`

When no `WEB3FORMS_ACCESS_KEY` is configured, the backend returns a development OTP in the browser alert and logs it in the backend terminal. Enter that OTP to sign in. This development OTP mode is for local testing only.

If you already have a `backend/.env` file, it overrides these defaults. Update its `ADMIN_EMAIL` and `ADMIN_PASSWORD` values to match the login details above, or remove the old `.env` file to use the defaults.

## Email setup (optional)
- Web3Forms is optional. To send admin OTPs by email, create a Web3Forms access key and set `WEB3FORMS_ACCESS_KEY` in `backend/.env`, then restart the server.
- EmailJS is a separate optional service for customer email notifications. It is only shown as configured when Service ID, Template ID and Public Key are all saved.
- Saving a Web3Forms key in the browser is not the same as configuring the backend OTP provider. Backend OTP email requires the environment variable.

## Data files
- `backend/data/seed.json` — initial demo data.
- `backend/data/db.json` — live local database. Back it up before replacing the project.

## Procurement modules
- Vendor Master: add, edit and delete vendors. A vendor linked to a PO cannot be deleted.
- Purchase Orders: create and edit pending POs, receive POs and delete pending POs.
- Vendor ID is validated against Vendor Master.
- SKU ID is validated against Inventory; procurement is currently restricted to Raw Material SKUs.
- Amount is calculated by the backend as quantity × price.
- Receiving a PO updates both the Inventory SKU quantity and the corresponding Raw Materials quantity.
- Received POs are locked to protect the stock movement history.

## API diagnostics
- `GET /api/status` is a public health/status endpoint showing whether the local JSON data folder is writable and counts of records.
- `GET /api/health` checks that the API server is responding.
- Procurement endpoints require an authenticated admin session.

## Before deployment
Change the development credentials and JWT secret, configure an email provider, use HTTPS, implement rate limiting and audit logging, and use a production database if multiple concurrent users or remote access are required.


## Vendor Master and Purchase Orders

Run the application using `START_ONEKID.bat` on Windows, or from `backend/` run `npm start`.
Open `http://localhost:5000` (do not open the HTML file directly).

After signing into Admin:
1. Open **Vendor Master** and choose **Add Vendor**. Enter a vendor name and address, then save.
2. Open **Purchase Orders** and choose **New Purchase Order**.
3. Select the vendor you created and an existing raw-material SKU, then enter quantity and unit price.
4. The amount is calculated as quantity × price. Choose **Create PO** to save it.
5. When the goods physically arrive, choose **Receive** on that PO. The linked Inventory and Raw Materials quantities increase.

Customer Sales Orders are a separate workflow: they deduct finished-goods stock and do not create supplier purchase orders.


### Local admin credentials

- Email: `rahulpamnani2001@gmail.com`
- Password: `admin123`

The backend checks credentials in `backend/src/server.js`. If a `backend/.env` file exists, its `ADMIN_EMAIL` and `ADMIN_PASSWORD` values override these defaults. To use the credentials above, either update those two values in `.env` or temporarily rename/remove that file for local development. Restart the backend after changing credentials.


## Customer order confirmation emails (EmailJS)

Customer confirmation emails use EmailJS; the Web3Forms access key is used separately for the admin order notification. In Admin → Integration Setup → Customer Emails, enter the EmailJS Service ID, Template ID and Public Key, then save. These settings are saved in browser local storage and restored after a page reload.

The EmailJS email template must have its **To Email** field set to `{{to_email}}` (or the equivalent EmailJS variable field), and its template should use the parameters sent by the app: `to_name`, `to_email`, `order_id`, `order_date`, `order_time`, `items_list`, `subtotal`, `gst`, `shipping`, `total`, `address`, `phone`, `admin_email`, and `admin_address`.

A successful sales order is saved before email delivery is attempted. If email delivery fails, the order remains placed; the confirmation screen now shows the provider error to help diagnose the configuration. Actual delivery must be verified using a real EmailJS account/service/template.


## Where to find Raw Material Inventory
After starting the application and signing into Admin, open the Admin dashboard. The **Inventory** tab is for finished products only. Select **Raw Materials** beside it to view the separate raw-material stock register, including material ID, name, location, quantity, unit, price, total value and stock status. The Raw Materials tab refreshes its data from the backend whenever it is opened.

## Demo data added in this package
- Three open (PENDING) purchase orders have been added for Denim Fabric (RM004), Silk Blend Fabric (RM005) and Zippers (RM009). These are demo purchase orders and do not increase raw-material stock until you select **Receive** in the Purchase Orders tab.
- Finished-goods stock for Denim Dungarees (DUN004) and Ethnic Kurta (KUR001), which were at zero in the supplied database, has been replenished to 20 and 15 units respectively for demonstration. The corresponding product and inventory records are kept in sync.
- Purchase orders are kept pending deliberately; receiving them later increases the linked raw-material inventory.


## Inventory display correction
- Raw Materials are loaded independently from the `/api/raw-materials` endpoint, so a separate Production API issue will not prevent the materials table from rendering.
- Opening the Raw Materials tab refreshes the list from the JSON backend.
- Quantity, price, minimum quantity, units and product-use fields are normalised before rendering to prevent missing or malformed fields from breaking the table.
- The Inventory tab is explicitly the finished-goods register; raw materials are displayed in the adjacent Raw Materials tab.
